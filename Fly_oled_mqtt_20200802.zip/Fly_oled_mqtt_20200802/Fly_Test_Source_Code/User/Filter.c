#include "Headfile.h"
#include "Filter.h"

float LPButterworth(float curr_input,Butterworth_BufferData *Buffer,Butterworth_Parameter *Parameter){

	static int LPB_Cnt=0;
	//��ȡ����x(n)
	Buffer->Input_Butter[2] = curr_input;
	
	if(LPB_Cnt >=100){
		
		Buffer->Output_Butter[2] = Parameter->b[0] * Buffer->Input_Butter[2]
		                           + Parameter->b[1] * Buffer->Input_Butter[1]
                               + Parameter->b[2] * Buffer->Input_Butter[0]
		                           - Parameter->a[1] * Buffer->Output_Butter[1]
		                           - Parameter->a[2] * Buffer->Output_Butter[0];
	} 
	else{
		
		Buffer->Input_Butter[2] = Buffer->Input_Butter[2];
    LPB_Cnt++;
	}
	
	// x(n) ���б���
	Buffer->Input_Butter[0] = Buffer->Input_Butter[1];
	Buffer->Input_Butter[1] = Buffer->Input_Butter[2];
	
	// y(n) ���б���
	Buffer->Output_Butter[0] = Buffer->Output_Butter[1];
	Buffer->Output_Butter[1] = Buffer->Output_Butter[2];
	
	return Buffer->Output_Butter[2];

}

float MPU_LPF(float curr_inputer,
               Butterworth_BufferData *Buffer,
               Butterworth_Parameter *Parameter)
{
        /* ????Butterworth?? */
	/* ????x(n) */
        Buffer->Input_Butter[2]=curr_inputer;
	/* Butterworth?? */
        Buffer->Output_Butter[2]=
         Parameter->b[0] * Buffer->Input_Butter[2]
        +Parameter->b[1] * Buffer->Input_Butter[1]
	+Parameter->b[2] * Buffer->Input_Butter[0]
        -Parameter->a[1] * Buffer->Output_Butter[1]
        -Parameter->a[2] * Buffer->Output_Butter[0];
	/* x(n) ???? */
        Buffer->Input_Butter[0]=Buffer->Input_Butter[1];
        Buffer->Input_Butter[1]=Buffer->Input_Butter[2];
	/* y(n) ???? */
        Buffer->Output_Butter[0]=Buffer->Output_Butter[1];
        Buffer->Output_Butter[1]=Buffer->Output_Butter[2];
        return (Buffer->Output_Butter[2]);
}



