#include "Headfile.h"
#include "USART.h"
#include <stdarg.h>
#include <string.h>
#include <stdio.h>

uint8_t data_to_send[50];

vs32 ALT_USE = 1;
void USART1_Init(unsigned long bound){
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1 | RCC_APB2Periph_AFIO, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  //�����������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;  //��������
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);


	USART_InitStructure.USART_BaudRate = bound;//
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//8bits
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//stop bit is 1
	USART_InitStructure.USART_Parity = USART_Parity_No;//no parity
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//no Hardware Flow Control
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;//enable tx and rx
	USART_Init(USART1, &USART_InitStructure);//

	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);//rx interrupt is enable  ���������ж�
	USART_Cmd(USART1, ENABLE);

}
void USART2_Init(unsigned long bound){
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);//����2 ����
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  //�����������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;  //��������
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);


	USART_InitStructure.USART_BaudRate = bound;//
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//8bits
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//stop bit is 1
	USART_InitStructure.USART_Parity = USART_Parity_No;//no parity
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//no Hardware Flow Control
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;//enable tx and rx
	USART_Init(USART2, &USART_InitStructure);//

	USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);//rx interrupt is enable  ���������ж�
	USART_Cmd(USART2, ENABLE);

}
void USART3_Init(unsigned long bound){
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
/*
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);


	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  //�����������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;  //��������
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);


	USART_InitStructure.USART_BaudRate = bound;//
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//8bits
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//stop bit is 1
	USART_InitStructure.USART_Parity = USART_Parity_No;//no parity
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//no Hardware Flow Control
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;//enable tx and rx
	USART_Init(USART3, &USART_InitStructure);//

	USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);//rx interrupt is enable  ���������ж�
	USART_Cmd(USART3, ENABLE);GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;//
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//8bits
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//stop bit is 1
	USART_InitStructure.USART_Parity = USART_Parity_No;//no parity
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//no Hardware Flow Control
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;//enable tx and rx
	USART_Init(USART3, &USART_InitStructure);//
	USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);//rx interrupt is enable
	USART_Cmd(USART3, ENABLE);

}

void UART3_Send(unsigned char *tx_buf, int len)
{
		USART_ClearFlag(USART3, USART_FLAG_TC);
		USART_ClearITPendingBit(USART3, USART_FLAG_TXE);
	while(len--)
	{
		USART_SendData(USART3, *tx_buf);
		while(USART_GetFlagStatus(USART3, USART_FLAG_TC) != 1);
		USART_ClearFlag(USART3, USART_FLAG_TC);
		USART_ClearITPendingBit(USART3, USART_FLAG_TXE);
		tx_buf++;
	}
}
u8 TxBuffer[256];
u8 TxCounter=0;
u8 count=0; 
void USART3_IRQHandler(void)
{
	/*
      if(USART_GetFlagStatus(USART3, USART_FLAG_RXNE) == SET)
      {
        uint8_t ch3=USART_ReceiveData(USART3);
        ANO_DT_Data_Receive_Prepare(ch3);

        if(Frame_Header_IS_Okay==1)
        {
          OpticalFlow_Data_Cnt++;
          if(OpticalFlow_Data_Cnt>=1)
          {
            OpticalFlow_Data_Buffer[OpticalFlow_Data_Cnt-1]=ch3;
          }
          if(OpticalFlow_Data_Cnt>=15)
          {
            Frame_Header_IS_Okay=0;
            OpticalFlow_Data_IS_Okay=1;
            Test_Period(&Time_UASRT3);//20ms
          }
        }
        if(ch3==0xAA&&Frame_Header_IS_Okay==0)
        {
          Frame_Header_IS_Okay=1;
          OpticalFlow_Data_Cnt=0;
        }
        
      }
      USART_ClearITPendingBit(USART3, USART_IT_RXNE);
			*/
				u8 com_data;
	
	if(USART3->SR & USART_SR_ORE)//ORE??
	{
		com_data = USART3->DR;
	}

  //????
	if( USART_GetITStatus(USART3,USART_IT_RXNE) )
	{
		USART_ClearITPendingBit(USART3,USART_IT_RXNE);//??????

		com_data = USART3->DR;
		ANO_DT_Data_Receive_Prepare(com_data);
	}
	//??(????)??
	/*if( USART_GetITStatus(USART3,USART_IT_TXE ) )
	{
				
		USART3->DR = TxBuffer[TxCounter++]; //?DR??????          
		if(TxCounter == count)
		{
			USART3->CR1 &= ~USART_CR1_TXEIE;		//??TXE(????)??
		}
*

		//USART_ClearITPendingBit(USART2,USART_IT_TXE);
	}
  */

}


/*
void USART1_IRQHandler(void){
	unsigned char Res;
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
	{
		Rec_Ust++;
	  Res = USART_ReceiveData(USART1);
                if(Res==0xff)
		{
                  Rec_Ready=1;
                  Rec_Cnt=0;
		}
		if(Rec_Ready==1)
		{
		  Rec_Cnt++;
		}
                if(Rec_Cnt>=3)
		{
		RecBag[Rec_Cnt-3]=Res;
		if(Rec_Cnt==5)
		{
                  Rec_Cnt=0;
                  Rec_Ready=0;
	  //UART1_Send(RecBag[0]);
	  //UART1_Send(RecBag[1]);
	  //UART1_Send(RecBag[2]);
		}
		}
          USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
}*/
//Data_Receive_Prepare������Э��Ԥ����������Э��ĸ�ʽ�����յ������ݽ���һ�θ�ʽ�Խ�������ʽ��ȷ�Ļ��ٽ������ݽ���
//��ֲʱ���˺���Ӧ���û���������ʹ�õ�ͨ�ŷ�ʽ���е��ã����紮��ÿ�յ�һ�ֽ����ݣ�����ô˺���һ��
//�˺������������ϸ�ʽ������֡�󣬻����е������ݽ�������
void ANO_DT_Data_Receive_Prepare(u8 data)
{
	static u8 RxBuffer[50];
	static u8 _data_len = 0,_data_cnt = 0;
	static u8 state = 0;
	
	if(state==0&&data==0xAA)
	{
		state=1;
		RxBuffer[0]=data;
	}
	else if(state==1&&data==0xAF)
	{
		state=2;
		RxBuffer[1]=data;
	}
	else if(state==2&&data<0XF1)
	{
		state=3;
		RxBuffer[2]=data;
	}
	else if(state==3&&data<50)
	{
		state = 4;
		RxBuffer[3]=data;
		_data_len = data;
		_data_cnt = 0;
	}
	else if(state==4&&_data_len>0)
	{
		_data_len--;
		RxBuffer[4+_data_cnt++]=data;
		if(_data_len==0)
			state = 5;
	}
	else if(state==5)
	{
		state = 0;
		RxBuffer[4+_data_cnt]=data;
		ANO_DT_Data_Receive_Anl(RxBuffer,_data_cnt+5);
	}
	else
		state = 0;	
}
/////////////////////////////////////////////////////////////////////////////////////
//Data_Receive_Anl������Э�����ݽ������������������Ƿ���Э���ʽ��һ������֡���ú��������ȶ�Э�����ݽ���У��
//У��ͨ��������ݽ��н�����ʵ����Ӧ����
//�˺������Բ����û����е��ã��ɺ���Data_Receive_Prepare�Զ�����
uint8_t ANO_Send_PID_Flag[6]={0};
void ANO_DT_Data_Receive_Anl(u8 *data_buf,u8 num)
{
	u8 sum = 0, i=0;
	for(i=0;i<(num-1);i++)
		sum += *(data_buf+i);
	if(!(sum==*(data_buf+num-1)))		return;		//�ж�sum
	if(!(*(data_buf)==0xAA && *(data_buf+1)==0xAF))		return;		//�ж�֡ͷ
	
	if(*(data_buf+2)==0X01)
	{
		if(*(data_buf+4)==0X01)
		{
      //mpu6050.Acc_CALIBRATE = 1;
			//mpu6050.Cali_3d = 1;
		}
		if(*(data_buf+4)==0X02)
		{
			//mpu6050.Gyro_CALIBRATE = 1;
		} 
		if(*(data_buf+4)==0X03)
		{
			//mpu6050.Acc_CALIBRATE = 1;		
			//mpu6050.Gyro_CALIBRATE = 1;			
		}
	}
	
	if(*(data_buf+2)==0X02)
	{
		if(*(data_buf+4)==0X01)
		{
			ANO_Send_PID_Flag[0] = 1;
			ANO_Send_PID_Flag[1] = 1;
			//ANO_Send_PID_Flag[2] = 1;
			//ANO_Send_PID_Flag[3] = 1;
			//ANO_Send_PID_Flag[4] = 1;
		 // ANO_Send_PID_Flag[5] = 1;
		}
		if(*(data_buf+4)==0X02)
		{
			
		}
		if(*(data_buf+4)==0XA0)		//��ȡ�汾��Ϣ
		{
			//f.send_version = 1;
		}
		if(*(data_buf+4)==0XA1)		//�ָ�Ĭ�ϲ���
		{
			PID_flash_Write_Flag=2;
		}
	}
/*
	if(*(data_buf+2)==0X03)
	{
		if( NS != 1 )
		{
			Feed_Rc_Dog(2);
		}

		RX_CH[THR] = (vs16)(*(data_buf+4)<<8)|*(data_buf+5) ;
		RX_CH[YAW] = (vs16)(*(data_buf+6)<<8)|*(data_buf+7) ;
		RX_CH[ROL] = (vs16)(*(data_buf+8)<<8)|*(data_buf+9) ;
		RX_CH[PIT] = (vs16)(*(data_buf+10)<<8)|*(data_buf+11) ;
		RX_CH[AUX1] = (vs16)(*(data_buf+12)<<8)|*(data_buf+13) ;
		RX_CH[AUX2] = (vs16)(*(data_buf+14)<<8)|*(data_buf+15) ;
		RX_CH[AUX3] = (vs16)(*(data_buf+16)<<8)|*(data_buf+17) ;
		RX_CH[AUX4] = (vs16)(*(data_buf+18)<<8)|*(data_buf+19) ;
		
	}
*/
	if(*(data_buf+2)==0X10)								//PID1
    {
        Roll_Gyro_Control.Kp  = 0.001*( (vs16)(*(data_buf+4)<<8)|*(data_buf+5) );
        Roll_Gyro_Control.Ki  = 0.001*( (vs16)(*(data_buf+6)<<8)|*(data_buf+7) );
        Roll_Gyro_Control.Kd  = 0.001*( (vs16)(*(data_buf+8)<<8)|*(data_buf+9) );
        Pitch_Gyro_Control.Kp = 0.001*( (vs16)(*(data_buf+10)<<8)|*(data_buf+11) );
        Pitch_Gyro_Control.Ki  = 0.001*( (vs16)(*(data_buf+12)<<8)|*(data_buf+13) );
        Pitch_Gyro_Control.Kd  = 0.001*( (vs16)(*(data_buf+14)<<8)|*(data_buf+15) );
        Yaw_Gyro_Control.Kp 	= 0.001*( (vs16)(*(data_buf+16)<<8)|*(data_buf+17) );
        Yaw_Gyro_Control.Ki 	= 0.001*( (vs16)(*(data_buf+18)<<8)|*(data_buf+19) );
        Yaw_Gyro_Control.Kd 	= 0.001*( (vs16)(*(data_buf+20)<<8)|*(data_buf+21) );
			
			  ANO_DT_Send_Check(*(data_buf+2), sum);
			
			 // 
				
    }
    if(*(data_buf+2)==0X11)								//PID2
    {
        Roll_Angle_Control.Kp  = 0.001*( (vs16)(*(data_buf+4)<<8)|*(data_buf+5) );
        Roll_Angle_Control.Ki  = 0.001*( (vs16)(*(data_buf+6)<<8)|*(data_buf+7) );
        Roll_Angle_Control.Kd  = 0.001*( (vs16)(*(data_buf+8)<<8)|*(data_buf+9) );
        Pitch_Angle_Control.Kp = 0.001*( (vs16)(*(data_buf+10)<<8)|*(data_buf+11) );
        Pitch_Angle_Control.Ki  = 0.001*( (vs16)(*(data_buf+12)<<8)|*(data_buf+13) );
        Pitch_Angle_Control.Kd  = 0.001*( (vs16)(*(data_buf+14)<<8)|*(data_buf+15) );
        Yaw_Angle_Control.Kp 	= 0.001*( (vs16)(*(data_buf+16)<<8)|*(data_buf+17) );
        Yaw_Angle_Control.Ki 	= 0.001*( (vs16)(*(data_buf+18)<<8)|*(data_buf+19) );
        Yaw_Angle_Control.Kd 	= 0.001*( (vs16)(*(data_buf+20)<<8)|*(data_buf+21) );
       
				
				ANO_DT_Send_Check(*(data_buf+2), sum);
			  
    }
    if(*(data_buf+2)==0X12)								//PID3
    {	
       ANO_DT_Send_Check(*(data_buf+2), sum);
    }
	  if(*(data_buf+2)==0X13)								//PID4
	  {
			ANO_DT_Send_Check(*(data_buf+2), sum);
	  }
	  if(*(data_buf+2)==0X14)								//PID5
	  {
			ANO_DT_Send_Check(*(data_buf+2), sum);
	  }
	  if(*(data_buf+2)==0X15)								//PID6
	  {
			ANO_DT_Send_Check(*(data_buf+2), sum);
			PID_flash_Write_Flag=1;
	  }
}
//�ɿسɹ�  ���յ����� ������ڷ���check    �� ֡ͷ ��sum�
static void ANO_DT_Send_Check(u8 head, u8 check_sum)
{
	u8 sum = 0, i=0;
	
	data_to_send[0]=0xAA;
	data_to_send[1]=0xAA;
	data_to_send[2]=0xEF;
	data_to_send[3]=2;
	data_to_send[4]=head;
	data_to_send[5]=check_sum;
	
	
	
	for(i=0;i<6;i++)
		sum += data_to_send[i];
	data_to_send[6]=sum;

	UART3_Send_2(data_to_send, 7);
}

/****************����1�жϷ��������ڽ�������*****************************/
//uint8_t Rec_Cnt=0;
//uint8_t Rec_Start=0;
//uint8_t RecBag[3]={0};
//uint8_t Rec_Ready=0;
//uint16_t Rec_Ust=0;
//void USART1_IRQHandler(void)
//{
//	unsigned char Res;
//	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
//	{
//		Rec_Ust++;
//	  Res = USART_ReceiveData(USART1);
//                if(Res==0xff)
//		{
//                  Rec_Ready=1;
//                  Rec_Cnt=0;
//		}
//		if(Rec_Ready==1)
//		{
//		  Rec_Cnt++;
//		}
//                if(Rec_Cnt>=3)
//		{
//		RecBag[Rec_Cnt-3]=Res;
//		if(Rec_Cnt==5)
//		{
//                  Rec_Cnt=0;
//                  Rec_Ready=0;
//	  //UART1_Send(RecBag[0]);
//	  //UART1_Send(RecBag[1]);
//	  //UART1_Send(RecBag[2]);
//		}
//		}
//          USART_ClearITPendingBit(USART1, USART_IT_RXNE);
//    }
//	/*
//  uint8_t com_data;
//  if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
//  {
//		USART_ClearITPendingBit(USART1,USART_IT_RXNE); //����жϱ�־λ
//	  com_data = USART_ReceiveData(USART1);  //����1��Byte    һ���ֽ�
//		ANO_DT_Data_Receive_Prepare(com_data);
//  }
//	
//		 else if(USART_GetFlagStatus(USART1,USART_FLAG_ORE) != RESET) //
//	 {
//			USART_ClearFlag(USART1,USART_FLAG_ORE); //��SR 
//		  USART_ReceiveData(USART1); //��DR 
//	
//	 }
//	 
//	 if (USART_GetFlagStatus(USART1, USART_FLAG_PE) != RESET)
//   {
//       USART_ReceiveData(USART1);
//     USART_ClearFlag(USART1, USART_FLAG_PE);
//   }
//    
//   if (USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET)
//   {
//       com_data=USART_ReceiveData(USART1);
//     USART_ClearFlag(USART1, USART_FLAG_ORE);
//   }
//    
//    if (USART_GetFlagStatus(USART1, USART_FLAG_FE) != RESET)
//   {
//       com_data=USART_ReceiveData(USART1);
//      USART_ClearFlag(USART1, USART_FLAG_FE);
//   }
//    
//    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
//    {   
//        USART_ClearFlag(USART1, USART_FLAG_RXNE);
//        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
//        com_data = USART_ReceiveData(USART1);  //����1��Byte    һ���ֽ�
//		    ANO_DT_Data_Receive_Prepare(com_data);
//    }
//    */
//}


/****************����1�жϷ��������ڽ�����λ�����͹���������*****************************/
/*
uint8_t Uart1_Buffer[256];
int Uart1_Rx=0;
int Uart1_Tx=0, Uart1_Len=0,Uart1_Sta=0;
void USART1_IRQHandler() 
{
	if(USART_GetITStatus(USART1,USART_IT_RXNE) != RESET) //�жϲ���
	{
		USART_ClearITPendingBit(USART1,USART_IT_RXNE); //����жϱ�־λ
		Uart1_Buffer[Uart1_Rx] = USART_ReceiveData(USART1); 
		Uart1_Rx++; 
    Uart1_Rx &= 0xFF; 
	}
	if(Uart1_Buffer[Uart1_Rx-1] == 0x5A) //��ͷ
	   Uart1_Tx = Uart1_Rx-1; 
	 if((Uart1_Buffer[Uart1_Tx] == 0x5A)&&(Uart1_Buffer[Uart1_Rx-1] == 0xA5)) //��⵽ͷ������¼��β��
	 {
		 
		 Uart1_Len = Uart1_Rx-1- Uart1_Tx; //����
		 Uart1_Sta=1; //��־λ
	 }
	 if(USART_GetFlagStatus(USART1,USART_FLAG_ORE) == SET) //���
	 {
			USART_ClearFlag(USART1,USART_FLAG_ORE); //��SR 
		  USART_ReceiveData(USART1); //��DR 
	 }
	 
}
*/

/*  ����main()�� ѭ����ѯ
   if( Uart2_Sta ) 
{ 
        for(tx2=0;tx2 <= Uart2_Len;tx2++,Uart2_Tx++) 
                USART2_SendByte(Uart2_Buffer[Uart2_Tx]); //��������
        Uart2_Rx = 0; //??? 
        Uart2_Tx = 0; 
        Uart2_Sta = 0; 
}


*/


void UART1_Send(unsigned char *tx_buf, int len)
{
		USART_ClearFlag(USART1, USART_FLAG_TC);
		USART_ClearITPendingBit(USART1, USART_FLAG_TXE);
	while(len--)
	{
		USART_SendData(USART1, *tx_buf);   //STM32�⺯��USART_SendData(USARTx, *tx_buf);
		while(USART_GetFlagStatus(USART1, USART_FLAG_TC) != 1);
		USART_ClearFlag(USART1, USART_FLAG_TC);
		USART_ClearITPendingBit(USART1, USART_FLAG_TXE);
		tx_buf++;
	}
}

//��������Э��
void ANO_DT_Send_Senser(s16 a_x,s16 a_y,s16 a_z,s16 g_x,s16 g_y,s16 g_z,s16 m_x,s16 m_y,s16 m_z)
{
    u8 _cnt=0;
    vs16 _temp;
    u8 sum = 0;
    u8 i=0;
    data_to_send[_cnt++]=0xAA;
    data_to_send[_cnt++]=0xAA;
    data_to_send[_cnt++]=0x02;
    data_to_send[_cnt++]=0;

    _temp = a_x;
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = a_y;
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = a_z;
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);

    _temp = g_x;
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = g_y;
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = g_z;
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);

    _temp = m_x;
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = m_y;
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = m_z;
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
   
    data_to_send[3] = _cnt-4;

    sum = 0;
    for(i=0;i<_cnt;i++)
        sum += data_to_send[i];
    data_to_send[_cnt++] = sum;
    //Quad_DMA1_USART3_SEND((u32)(data_to_send),_cnt);
    UART3_Send(data_to_send, _cnt);
}

/* ������̬�� ����ģʽ����״̬ ��Ϣ*/
void ANO_SEND_Status(void)
{
	u8 _cnt = 0;
	vs16 _temp;
	vs32 _temp2;
	u8 sum = 0;
	u8 i;
	data_to_send[_cnt++]=0xAA;
	data_to_send[_cnt++]=0xAA;
	data_to_send[_cnt++]=0x01;
	data_to_send[_cnt++]=0;

	_temp = (int)(Roll*100);
	data_to_send[_cnt++]=BYTE1(_temp);
	data_to_send[_cnt++]=BYTE0(_temp);
	_temp = (int)(Pitch*100);
	data_to_send[_cnt++]=BYTE1(_temp);
	data_to_send[_cnt++]=BYTE0(_temp);
	_temp = (int)(Yaw*100);
	data_to_send[_cnt++]=BYTE1(_temp);
	data_to_send[_cnt++]=BYTE0(_temp);

	//_temp2 = (vs32)(100*NamelessQuad.Position[_YAW]);//??cm
	_temp2 = (vs32)ALT_USE*100;
	data_to_send[_cnt++]=BYTE3(_temp2);
	data_to_send[_cnt++]=BYTE2(_temp2);
	data_to_send[_cnt++]=BYTE1(_temp2);
	data_to_send[_cnt++]=BYTE0(_temp2);

        data_to_send[_cnt++]=0x01;//����ģʽ
        data_to_send[_cnt++]=Controler_State;//����0 ����1
 
	data_to_send[3] = _cnt-4;
	sum = 0;
	for(i=0;i<_cnt;i++)
		sum += data_to_send[i];
	data_to_send[_cnt++]=sum;
       // Quad_DMA1_USART3_SEND((u32)(data_to_send),_cnt);
        UART3_Send(data_to_send, _cnt);
}


//����ң��ͨ����Ϣ
void ANO_DT_Send_RCData(s16 thr,s16 yaw,s16 rol,s16 pit,s16 aux1,s16 aux2,s16 aux3,s16 aux4,s16 aux5,s16 aux6)
{
    u8 _cnt=0;
    u8 i=0;
    u8 sum = 0;
    data_to_send[_cnt++]=0xAA;
    data_to_send[_cnt++]=0xAA;
    data_to_send[_cnt++]=0x03;
    data_to_send[_cnt++]=0;
    data_to_send[_cnt++]=BYTE1(thr);
    data_to_send[_cnt++]=BYTE0(thr);
    data_to_send[_cnt++]=BYTE1(yaw);
    data_to_send[_cnt++]=BYTE0(yaw);
    data_to_send[_cnt++]=BYTE1(rol);
    data_to_send[_cnt++]=BYTE0(rol);
    data_to_send[_cnt++]=BYTE1(pit);
    data_to_send[_cnt++]=BYTE0(pit);
    data_to_send[_cnt++]=BYTE1(aux1);
    data_to_send[_cnt++]=BYTE0(aux1);
    data_to_send[_cnt++]=BYTE1(aux2);
    data_to_send[_cnt++]=BYTE0(aux2);
    data_to_send[_cnt++]=BYTE1(aux3);
    data_to_send[_cnt++]=BYTE0(aux3);
    data_to_send[_cnt++]=BYTE1(aux4);
    data_to_send[_cnt++]=BYTE0(aux4);
    data_to_send[_cnt++]=BYTE1(aux5);
    data_to_send[_cnt++]=BYTE0(aux5);
    data_to_send[_cnt++]=BYTE1(aux6);
    data_to_send[_cnt++]=BYTE0(aux6);

    data_to_send[3] = _cnt-4;

    sum = 0;
    for(i=0;i<_cnt;i++)
        sum += data_to_send[i];

    data_to_send[_cnt++]=sum;
    //Quad_DMA1_USART3_SEND((u32)(data_to_send),_cnt);
    UART3_Send(data_to_send, _cnt);
}

void ANO_DT_Send_PID(u8 group,float p1_p,float p1_i,float p1_d,float p2_p,float p2_i,float p2_d,float p3_p,float p3_i,float p3_d)
{
    u8 _cnt=0;
	  u8 sum = 0,i=0;
    int16_t _temp;

    data_to_send[_cnt++]=0xAA;
    data_to_send[_cnt++]=0xAA;
    data_to_send[_cnt++]=0x10+group-1;
    data_to_send[_cnt++]=0;


    _temp = (int16_t)(p1_p * 1000);
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = (int16_t)(p1_i  * 1000);
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = (int16_t)(p1_d  * 100);
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = (int16_t)(p2_p  * 1000);
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = (int16_t)(p2_i  * 1000);
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = (int16_t)(p2_d * 100);
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = (int16_t)(p3_p  * 1000);
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = (int16_t)(p3_i  * 1000);
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);
    _temp = (int16_t)(p3_d * 100);
    data_to_send[_cnt++]=BYTE1(_temp);
    data_to_send[_cnt++]=BYTE0(_temp);

    data_to_send[3] = _cnt-4;


    for(i=0;i<_cnt;i++)
        sum += data_to_send[i];

    data_to_send[_cnt++]=sum;

    //Quad_DMA1_USART3_SEND((u32)(data_to_send),_cnt);
    UART3_Send_2(data_to_send, _cnt);
}


int16_t AN0_Cnt=0;
uint16_t send_cnt =0;
void SEND_STATAMACHINE_CONTROL(void)
{
	send_cnt++;
	if(send_cnt>=3)
	{
		ANO_SEND_StateMachine();
		send_cnt=0;
	}
	
}

void ANO_SEND_StateMachine(void){
	AN0_Cnt++;
	if(AN0_Cnt==1 && ANO_Send_PID_Flag[0]==0
		                 && ANO_Send_PID_Flag[1]==0) 
	{
		ANO_SEND_Status();
	}
	else if(AN0_Cnt==2 && ANO_Send_PID_Flag[0]==0
		                 && ANO_Send_PID_Flag[1]==0)
	{
		/*
			ANO_DT_Send_Senser((int16_t)Filter_Corret_Acc_X1,(int16_t)Filter_Corret_Acc_Y1,(int16_t)Filter_Corret_Acc_Z1,
                       (int16_t)Filter_Corret_Gyro_X1,(int16_t)Filter_Corret_Gyro_Y1,(int16_t)Filter_Corret_Gyro_Z1,
                       (int16_t)0,(int16_t)0,(int16_t)0);
		*/
		
			ANO_DT_Send_Senser((int16_t)Filter_Corret_Acc_X,(int16_t)Filter_Corret_Acc_Y,(int16_t)Filter_Corret_Acc_Z,
                       (int16_t)Filter_Corret_Gyro_X,(int16_t)Filter_Corret_Gyro_Y,(int16_t)Filter_Corret_Gyro_Z,
                       (int16_t)0,(int16_t)0,(int16_t)0);
		
	}
	
	
	else if(AN0_Cnt==3 && ANO_Send_PID_Flag[0]==0
		                 && ANO_Send_PID_Flag[1]==0)
	{
		ANO_DT_Send_RCData(PPM_Databuf[2],PPM_Databuf[3],
                     PPM_Databuf[0],PPM_Databuf[1],
                     PPM_Databuf[4],PPM_Databuf[5],
                     PPM_Databuf[6],PPM_Databuf[7],PPM_Databuf[8],PPM_Databuf[9]);
	}
	else if(AN0_Cnt==4 && ANO_Send_PID_Flag[0]==0
		                 && ANO_Send_PID_Flag[1]==0)
	{
		AN0_Cnt=0;
	}
	else if(AN0_Cnt==5 && ANO_Send_PID_Flag[0]==1 )
	{
    ANO_DT_Send_PID(1,Roll_Gyro_Control.Kp, 
                      Roll_Gyro_Control.Ki,
                      Roll_Gyro_Control.Kd,
                      Pitch_Gyro_Control.Kp,
                      Pitch_Gyro_Control.Ki,
                      Pitch_Gyro_Control.Kd,
                      Yaw_Gyro_Control.Kp,
                      Yaw_Gyro_Control.Ki,
                      Yaw_Gyro_Control.Kd);
		ANO_Send_PID_Flag[0]=0;
	}
	else if(AN0_Cnt==6
          &&ANO_Send_PID_Flag[1]==1)
 {
   ANO_DT_Send_PID(2,Roll_Angle_Control.Kp, 
                      Roll_Angle_Control.Ki,
                      Roll_Angle_Control.Kd,
                      Pitch_Angle_Control.Kp,
                      Pitch_Angle_Control.Ki,
                      Pitch_Angle_Control.Kd,
                      Yaw_Angle_Control.Kp,
                      Yaw_Angle_Control.Ki,
                      Yaw_Angle_Control.Kd);
    ANO_Send_PID_Flag[1]=0;
 }
 else if(AN0_Cnt==9)
 {
	 AN0_Cnt=0;
 }
	
}


void UART3_Send_2(unsigned char *tx_buf, int len)
{
		USART_ClearFlag(USART3, USART_FLAG_TC);
		USART_ClearITPendingBit(USART3, USART_FLAG_TXE);
	while(len--)
	{
		USART_SendData(USART3, *tx_buf);
		while(USART_GetFlagStatus(USART3, USART_FLAG_TC) != 1);
		USART_ClearFlag(USART3, USART_FLAG_TC);
		USART_ClearITPendingBit(USART3, USART_FLAG_TXE);
		tx_buf++;
	}
}


/*
************************************************************
*	�������ƣ�	Usart_SendString
*
*	�������ܣ�	�������ݷ���
*
*	��ڲ�����	USARTx��������
*				str��Ҫ���͵�����
*				len�����ݳ���
*
*	���ز�����	��
*
*	˵����		
************************************************************
*/
void Usart_SendString(USART_TypeDef *USARTx, unsigned char *str, unsigned short len)
{

	unsigned short count = 0;
	
	for(; count < len; count++)
	{
		USART_SendData(USARTx, *str++);									//��������
		while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);		//�ȴ��������
	}

}
/*
************************************************************
*	�������ƣ�	UsartPrintf
*
*	�������ܣ�	��ʽ����ӡ
*
*	��ڲ�����	USARTx��������
*				fmt����������
*
*	���ز�����	��
*
*	˵����		
************************************************************
*/
void UsartPrintf(USART_TypeDef *USARTx, char *fmt,...)
{

	unsigned char UsartPrintfBuf[296];
	va_list ap;
	unsigned char *pStr = UsartPrintfBuf;
	
	va_start(ap, fmt);
	vsnprintf((char *)UsartPrintfBuf, sizeof(UsartPrintfBuf), fmt, ap);							//��ʽ��
	va_end(ap);
	
	while(*pStr != 0)
	{
		USART_SendData(USARTx, *pStr++);
		while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
	}

}

