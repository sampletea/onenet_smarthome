#include "Headfile.h"
#include "PPM.h"



u16 Controler_State = 0;
void PPM_Init()
{
GPIO_InitTypeDef GPIO_InitStructure;
EXTI_InitTypeDef EXTI_InitStructure;
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_8;//GPIO_Pin_0
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//????
//GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_Init(GPIOA, &GPIO_InitStructure);
GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource8);
EXTI_InitStructure.EXTI_Line = EXTI_Line8;
EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
EXTI_InitStructure.EXTI_LineCmd	= ENABLE;
EXTI_Init(&EXTI_InitStructure);

}

uint16 PPM_Sample_Cnt=0;
uint16 PPM_Isr_Cnt=0;
u32 Last_PPM_Time=0;
u32 PPM_Time=0;
u16 PPM_Time_Delta=0;
u16 PPM_Time_Max=0;
uint16 PPM_Start_Time=0;
uint16 PPM_Finished_Time=0;
uint16 PPM_Is_Okay=0;
uint16 PPM_Databuf[10]={0};

/***************************************************
???: void EXTI9_5_IRQHandler(void)
??:	PPM??????
??:	?
??:	?
??:	???????????
****************************************************/
void EXTI9_5_IRQHandler(void)
{
  if(EXTI_GetITStatus(EXTI_Line8) != RESET)
  {
//????????,??us
    Last_PPM_Time=PPM_Time;
    PPM_Time=20000*TIME_ISR_CNT     //1ms =1000us 20ms = 20000us
                   +TIM4->CNT;//us
    PPM_Time_Delta=PPM_Time-Last_PPM_Time;
    //PPM??????
    if(PPM_Isr_Cnt<100)  PPM_Isr_Cnt++;
   //PPM????
    if(PPM_Is_Okay==1)
    {
    PPM_Sample_Cnt++;
    //?????????
    PPM_Databuf[PPM_Sample_Cnt-1]=PPM_Time_Delta;
    //??????
      if(PPM_Sample_Cnt>=8)
        PPM_Is_Okay=0;
    }
    if(PPM_Time_Delta>=2050)//???????2ms=2000us
    {
      PPM_Is_Okay=1;
      PPM_Sample_Cnt=0;
    }
  }
  EXTI_ClearITPendingBit(EXTI_Line8);
}






//////////////////////////////////
// PPM�������  1-4ͨ��
int16_t Throttle_Rate=0;
int16_t Get_Thr_Rate(float Thr)//?????
{
  static float Thr_Rec[20];
  uint16_t i=0;
  for(i=19;i>0;i--)
  {
     Thr_Rec[i]=Thr_Rec[i-1];
  }
  Thr_Rec[0]=Thr;
  return (int16_t)((Thr_Rec[0]-Thr_Rec[9])/1.0f);
}

uint16 Throttle_Control=0;
int16 Pitch_Control=0,Roll_Control=0,Yaw_Control=0;
int16 Target_Angle[2]={0};
uint8 RC_Control[32];
uint16 Last_Throttle_Control,Pre_Last_Throttle_Control;
uint16 Throttle_Base=1000,TempThrottle_Control;
uint16 QuadData[2];
uint8 QuadRemoteFlag[4]={0};
int16 RC_NewData[4]={0};
uint16 RC_Init_Cnt=0;

uint16_t Auto_ReLock_Cnt=0;//???????
uint8_t Auto_Relock_Flag=0;
uint8_t Auto_Relock_Flag_Set=0;
int16 Y_T=0,T_temp=0;
int16 Temp_RC=0;
uint16_t Unlock_Cnt=0,Lock_Cnt=0;
void PPM_RC(void)
{
	if(RC_Init_Cnt<=5)
  {
    Throttle_Control=1000;
    Pitch_Control=0;
    Roll_Control=0;
    Yaw_Control=0;
    RC_Init_Cnt++;
  }
	
#ifdef RC_PPM       //1500-50                                      1450-1000   
 

	 if(PPM_Databuf[0]<=1450)  Roll_Control=(1450-PPM_Databuf[0])*50/450;
   else if(PPM_Databuf[0]>=1550)  Roll_Control=(1550-PPM_Databuf[0])*50/450;
   else Roll_Control=0;
 if(Roll_Control>=50) Roll_Control=50;
 else if(Roll_Control<=-50) Roll_Control=-50;

 if(PPM_Databuf[1]<=1450)  Pitch_Control=(1450-PPM_Databuf[1])*50/450;
 else if(PPM_Databuf[1]>=1550)  Pitch_Control=(1550-PPM_Databuf[1])*50/450;
 else Pitch_Control=0;
 if(Pitch_Control>=50) Pitch_Control=50;
	else if(Pitch_Control<=-50) Pitch_Control=-50;
	

 Target_Angle[0]=-Pitch_Control;
 Target_Angle[1]=-Roll_Control;

 Temp_RC=(PPM_Databuf[2]-1100);
 if(Temp_RC<=5)     Throttle_Control=0;
 else if(Temp_RC>=1000)  Throttle_Control=1000;
 else Throttle_Control=Temp_RC;

 if(PPM_Databuf[3]<=1450)  Yaw_Control=-(PPM_Databuf[3]-1450)*100/450;
 else if(PPM_Databuf[3]>=1550)  Yaw_Control=-(PPM_Databuf[3]-1550)*100/450;
 else Yaw_Control=0;
 if(Yaw_Control>=100) Yaw_Control=100;
 else if(Yaw_Control<=-100) Yaw_Control=-100;

 RC_NewData[0]=Throttle_Control;//ң������ԭʼ�г�
 Throttle_Rate=Get_Thr_Rate(Throttle_Control);
 Throttle_Control=Throttle_Base+Throttle_Control;

 
#endif
  
    
	//�жϽ���������״̬�	
  if(Throttle_Control == 1000 && Yaw_Control>Yaw_Max*0.75 && Roll_Control==0 && Pitch_Control==0) Unlock_Cnt++;
	if(Throttle_Control == 1000 && Yaw_Control>Yaw_Max*0.75 && Roll_Control==0 && Pitch_Control==0 &&Unlock_Cnt>80*1) //2s
	{
		Controler_State = Lock_Controler;  //����
		Unlock_Cnt=0;
		LED_Set(&LED_3,3000,100,0.5,0,GPIOC,GPIO_Pin_5,0);
		LED_Set(&LED_4,3000,100,0.5,0,GPIOC,GPIO_Pin_10,0);
		LED_Set(&LED_5,3000,100,0.5,0,GPIOC,GPIO_Pin_4,0);
		LED_MODE=0;
	}
	if(Throttle_Control == 1000 && Yaw_Control<-Yaw_Max*0.75 && Roll_Control==0 && Pitch_Control==0) Lock_Cnt++;
	if(Throttle_Control == 1000 && Yaw_Control<-Yaw_Max*0.75 && Roll_Control==0 && Pitch_Control==0 && Lock_Cnt>80*1 && Check_Calibartion_Flag()==0x00) //��Ҫ�ڼӸ��Ƿ��� ����ģ��У׼ģʽ
	{
		Controler_State = Unlock_Controler;  //����
		Lock_Cnt=0;
		LED_Set(&LED_3,3000,200,0.3,0,GPIOC,GPIO_Pin_5,0);
		LED_Set(&LED_4,3000,200,0.5,0,GPIOC,GPIO_Pin_10,0);
		LED_Set(&LED_5,3000,200,0.9,0,GPIOC,GPIO_Pin_4,0);
		LED_MODE=0;
	}
	
}

