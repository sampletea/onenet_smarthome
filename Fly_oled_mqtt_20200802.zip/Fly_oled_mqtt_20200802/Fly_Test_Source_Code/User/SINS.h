#ifndef _SINS_H
#define _SINS_H

//�������Ե���ϵͳ
#define Axis_Num  3
#define Num  50
typedef struct
{
 float Position[Axis_Num];//?????
 float Speed[Axis_Num];//?????
 float Acceleration[Axis_Num];//??????
 float Pos_History[Axis_Num][Num];//??????
 float Vel_History[Axis_Num][Num];//??????
 float Acce_Bias[Axis_Num];//???????????
 float Last_Acceleration[Axis_Num];
 float Last_Speed[Axis_Num];
}SINS;



extern SINS Filter_Before, Filter_After, Filter_Feedback, Origin;  
extern Vector2f SINS_Accel_Body;

extern float Sin_Pitch,Sin_Roll,Sin_Yaw;
extern float Cos_Pitch,Cos_Roll,Cos_Yaw;


extern void Rotate_Body_To_Navigation_System_ACC(float Ab_X, float Ab_Y, float Ab_Z);
void  SINS_Prepare(void);
float constrain_float(float amt, float low, float high) ;
extern void imuComputeRotationMatrix(void);

#endif

