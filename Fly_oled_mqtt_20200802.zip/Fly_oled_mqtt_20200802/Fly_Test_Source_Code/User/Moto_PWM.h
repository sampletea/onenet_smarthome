#ifndef _Moto_PWM_H
#define _Moto_PWM_H

void Moto_PWM_Init(void);
extern void Set_PWM(const uint16_t pwm1, const uint16_t pwm2, const uint16_t pwm3, const uint16_t pwm4);

#endif
