#ifndef _USART_H
#define _USART_H
#include "Headfile.h"
#define USART_DEBUG		USART2		//���Դ�ӡ��ʹ�õĴ�����

extern void UsartPrintf(USART_TypeDef *USARTx, char *fmt,...);
extern void Usart_SendString(USART_TypeDef *USARTx, unsigned char *str, unsigned short len);
extern uint8_t ANO_Send_PID_Flag[6];
void USART2_Init(unsigned long  bound);
void USART1_Init(unsigned long  bound);
void UART1_Send(unsigned char *tx_buf, int len);
void ANO_DT_Send_Senser(s16 a_x,s16 a_y,s16 a_z,s16 g_x,s16 g_y,s16 g_z,s16 m_x,s16 m_y,s16 m_z);
void ANO_SEND_StateMachine(void);
void ANO_SEND_Status(void);
void ANO_DT_Send_RCData(s16 thr,s16 yaw,s16 rol,s16 pit,s16 aux1,s16 aux2,s16 aux3,s16 aux4,s16 aux5,s16 aux6);
void UART1_Receive(void);
void ANO_DT_Data_Receive_Prepare(u8 data);
void ANO_DT_Data_Receive_Anl(u8 *data_buf,u8 num);
	static void ANO_DT_Send_Check(u8 head, u8 check_sum);
	void UART3_Send(unsigned char *tx_buf, int len);
	void USART3_Init(unsigned long bound);
	void UART3_Send_2(unsigned char *tx_buf, int len);
void ANO_DT_Send_PID(u8 group,float p1_p,float p1_i,float p1_d,float p2_p,float p2_i,float p2_d,float p3_p,float p3_i,float p3_d);
void SEND_STATAMACHINE_CONTROL(void);



#endif
