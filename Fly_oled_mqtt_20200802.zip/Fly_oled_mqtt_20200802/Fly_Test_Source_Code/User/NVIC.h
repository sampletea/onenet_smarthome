#ifndef _NVIC_H
#define _NVIC_H



void NVIC_Configuration(void);
//void USART1_IRQHandler(void);
#endif
