#include "Headfile.h"
#include "Bling.h"

LED_Light LED_5,LED_2,LED_3,LED_4;

void Bling_Init(void){
	
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|
	                       RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD|
	                        RCC_APB2Periph_AFIO,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin=GPIO_Pin_5;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	//GPIO_SetBits(GPIOA, GPIO_Pin_5);
	//GPIO_SetBits(GPIOC, GPIO_Pin_4 | GPIO_Pin_10 | GPIO_Pin_5);
	//PCB������ �͵�ƽ����  �ߵ�ƽ��
	//Flag.Bling_Init_OK = 1;
}

//Blue LED ������
void Bling_Blue(void){
	
	GPIO_ResetBits(GPIOC, GPIO_Pin_10);
	Delay_Ms(500);
	GPIO_SetBits(GPIOC, GPIO_Pin_10);
	Delay_Ms(500);
	GPIO_ResetBits(GPIOC, GPIO_Pin_10);
	Delay_Ms(500);
	GPIO_SetBits(GPIOC, GPIO_Pin_10);
	
}

void Bling_Light_Out(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, unsigned char N ){
	int i;
	for ( i = 0; i < N; i++) {
	GPIO_ResetBits(GPIOx, GPIO_Pin);
	Delay_Ms(250);
	GPIO_SetBits(GPIOx, GPIO_Pin);
	Delay_Ms(250);
	}
	/*
	GPIO_ResetBits(GPIOx, GPIO_Pin_x);
	Delay_Ms(500);
	GPIO_SetBits(GPIOx, GPIO_Pin_x);
	*/
}

void Bling__Fast_Light_Out(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, unsigned char N ){
	int i;
	for ( i = 0; i < N; i++) {
	GPIO_ResetBits(GPIOx, GPIO_Pin);
	Delay_Ms(100);
	GPIO_SetBits(GPIOx, GPIO_Pin);
	Delay_Ms(100);
	}
	/*
	GPIO_ResetBits(GPIOx, GPIO_Pin_x);
	Delay_Ms(500);
	GPIO_SetBits(GPIOx, GPIO_Pin_x);
	*/
}
//LED_Set(&LED_5,2000,200,0.5,0,GPIOC,GPIO_Pin_4,0);
void LED_Set(LED_Light *LED, uint32_t continue_time, uint16_t Period,
	           float Percent, uint16_t Cnt, GPIO_TypeDef *GPIOx, uint16_t gpio_pin, uint8_t FFFlag)
{
	LED->led_bling_time = continue_time/4;
	LED->bling_period = Period; //����
	LED->Bling_Percent = Percent; //ռ�ձ�
	LED->led_Cnt = Cnt;
	LED->gpiox = GPIOx;
	LED->gpio_pin = gpio_pin;
	LED->Endless_mode = FFFlag;
}

void LED_Process(LED_Light *LED)
{
	if(LED->led_bling_time>=1)  LED->led_bling_time--; 
	else GPIO_SetBits(LED->gpiox, LED->gpio_pin); //���� ��
	if(LED->led_bling_time!=0 || LED->Endless_mode ==1)  //����ʱ��û���� 
	{
		LED->led_Cnt++;
		if(4*LED->led_Cnt>=LED->bling_period) LED->led_Cnt=0;     //bling_period ����
		if(4*LED->led_Cnt<=LED->bling_period*LED->Bling_Percent)     //Bling_Percent ռ�ձ�  �����ռʱ��ı�ֵ
			GPIO_ResetBits(LED->gpiox, LED->gpio_pin);   //�͵�ƽ ����
		else GPIO_SetBits(LED->gpiox, LED->gpio_pin);  //�ߵ�ƽ ��
	}
	
}

void LED_Work(uint16 led_mode)
{
	switch(led_mode)
	{
		case 0 : LED_Process(&LED_5);
		         LED_Process(&LED_2);
		         LED_Process(&LED_3);
		         LED_Process(&LED_4);break;
		case 1 : if(flight_direction==0)  // ���ټ�����У׼ģʽ ��һ��
		         {
							 LED_Process(&LED_5);
							 GPIO_SetBits(LED_2.gpiox,LED_2.gpio_pin);
							 GPIO_SetBits(LED_3.gpiox,LED_3.gpio_pin);
						 }
		         else if(flight_direction==1)		// ���ټ�����У׼ģʽ �ڶ���
		         {
							 LED_Process(&LED_2);
							 GPIO_SetBits(LED_3.gpiox,LED_3.gpio_pin);
							 GPIO_SetBits(LED_5.gpiox,LED_5.gpio_pin);
						 }
						 else if(flight_direction==2)		// ���ټ�����У׼ģʽ ������
		         {
							 LED_Process(&LED_5);
							 LED_Process(&LED_2);
							 GPIO_SetBits(LED_3.gpiox,LED_3.gpio_pin);
						 }
						 else if(flight_direction==3)		// ���ټ�����У׼ģʽ ������
		         {
							 LED_Process(&LED_3);
							 GPIO_SetBits(LED_2.gpiox,LED_2.gpio_pin);
							 GPIO_SetBits(LED_5.gpiox,LED_5.gpio_pin);
						 }
						 else if(flight_direction==4)		// ���ټ�����У׼ģʽ ������
		         {
							 LED_Process(&LED_5);
							 LED_Process(&LED_3);
							 GPIO_SetBits(LED_2.gpiox,LED_2.gpio_pin);
						 }
						  else if(flight_direction==5)		// ���ټ�����У׼ģʽ ������
		         {
							 LED_Process(&LED_2);
							 LED_Process(&LED_3);
							 GPIO_SetBits(LED_5.gpiox,LED_5.gpio_pin);
						 }
						 else
						 {
							 LED_Process(&LED_5);
		           LED_Process(&LED_2);
		           LED_Process(&LED_3);
		           LED_Process(&LED_4);
						 }
             	break;
		/*case 2 : if(Mag_Calibration_Mode==0)//������ˮƽ��У׼
               {
                 Bling_Process(&LED_5);
                 Bling_Process(&LED_2);
                 GPIO_SetBits(LED_3.gpiox,LED_3.gpio_pin);
               }	
						  else if(Mag_Calibration_Mode==1)//��ֱƽ��У׼
						  {
						    Bling_Process(&LED_3);
                Bling_Process(&LED_2);
                GPIO_SetBits(LED_5.gpiox,LED_5.gpio_pin);
						  }
						  else
						  {
						    LED_Process(&LED_5);
		            LED_Process(&LED_2);
		            LED_Process(&LED_3);
						  }
						  break;
    */						 
		default: LED_Process(&LED_5);
		         LED_Process(&LED_2);
		         LED_Process(&LED_3);
		         LED_Process(&LED_4);break;			 
	}
}

void Quad_Start_LED(void)
{
   LED_Set(&LED_5,2000,300,0.05,0,GPIOC,GPIO_Pin_4,0);
   LED_Set(&LED_4,2000,250,0.5,0,GPIOC,GPIO_Pin_5,0);
   LED_Set(&LED_3,2000,200,0.5,0,GPIOC,GPIO_Pin_10,0);
   LED_Set(&LED_2,2000,70,0.5,0,GPIOA,GPIO_Pin_5,1);
}

