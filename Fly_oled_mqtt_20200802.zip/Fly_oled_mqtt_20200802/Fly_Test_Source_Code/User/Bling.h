#ifndef _BLING_H
#define _BLING_H

typedef struct
{
	unsigned short led_bling_time;
	unsigned short bling_period;
  float  	Bling_Percent;
	unsigned short led_Cnt;
	GPIO_TypeDef* gpiox;
	unsigned short gpio_pin;
	unsigned char Endless_mode; 
}LED_Light;

extern LED_Light LED_5,LED_2,LED_3,LED_4;


void Bling_Init(void);
void Bling_Blue(void);
void Bling_Light_Out(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, unsigned char N );
void Bling__Fast_Light_Out(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, unsigned char N );

void LED_Process(LED_Light *LED);
void LED_Set(LED_Light *LED, uint32_t continue_time, uint16_t Period,
	           float Percent, uint16_t Cnt, GPIO_TypeDef *GPIOx, uint16_t gpio_pin, uint8_t FFFlag);
void LED_Work(uint16 led_mode);
void Quad_Start_LED(void);
#endif
