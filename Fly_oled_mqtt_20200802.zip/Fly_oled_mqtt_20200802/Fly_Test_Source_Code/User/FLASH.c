#include "Headfile.h"
#include "stm32f10x_flash.h"
#include "FLASH.h"

#define Acc_Offset_Address  0
#define Acc_Scale_Address  12
//#define Mag_Offset_Address  24
//MCU: 	STM32F103RCT6  72MHz  flash :256k   ������  ÿҳ 2k
//0X0800 0000
#define STM32_FLASH_BASE 0x08000000
#define STM32_FLASH_SIZE 256
#if STM32_FLASH_SIZE<256
#define STM_SECTOR_SIZE 1024 //�ֽ�
#else 
#define STM_SECTOR_SIZE    2048
#endif 
//#define FLASH_PAGE_SIZE 0x800    //2048 = 0x800  2k
#define WRITE_START_ADDR  0x0803b000    //0x3b000 ->ת10����=241664  /1024 =236  ---   256k-236k=20k  vbv                       
#define WRITE_END_ADDR    0x08040000      
                                         //134459392
                                         //134455296 

uint16_t STMFLASH_BUF[STM_SECTOR_SIZE/2];
volatile FLASH_Status FLASHStatus = FLASH_COMPLETE;
Parameter_Flag Parameter_Read_Flag;




void wtite_half_word(uint32_t write_addr, uint32_t write_data)
{
	uint32_t secpos; //������ַ =ҳ��ַ
	//uint16_t secoff; //������ƫ�Ƶ�ַ(16bit����)
	//uint16_t secremain;//������ʣ��  ��ַ(16bit����)
	//uint16_t i;
	uint32_t offaddr; //ȥ�� STM32_FLASH_BASE��ĵ�ַ
	
  if(write_addr<STM32_FLASH_BASE || (write_addr>=(STM32_FLASH_BASE+1024*STM32_FLASH_SIZE)))
		return; //�Ƿ���ַ
	
	offaddr = write_addr - STM32_FLASH_BASE; //ʵ��ƫ�Ƶ�ַ
	secpos = offaddr / STM_SECTOR_SIZE;    //������ַ 0~  stm32f10rct6
	//secoff = (offaddr % STM_SECTOR_SIZE) / 2 ; // �������ڵ�ƫ�ƣ�2���ֽ�Ϊ������λ��
	
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	FLASHStatus = FLASH_ErasePage(secpos*STM_SECTOR_SIZE+STM32_FLASH_BASE); // ��ַ TM�ľ���д����Ǹ���ַ���յ�
	if(FLASHStatus == FLASH_COMPLETE)
	{
		FLASHStatus = FLASH_ProgramHalfWord(secpos*STM_SECTOR_SIZE+STM32_FLASH_BASE, write_data);  //ע��д���ֻ�����
		//stm32f10x_flash.c �� API ����
	}
	FLASH_Lock();
}

/************1kb = 1024bit     8bit = 1 �ֽ�  4�ֽ� = 1����     float�������� ռ��4 ���ֽ�  2kb =2048bit  2048bit/32bit = 64�� *********/

Calibartion ACC_Cal_offset = {0,0,0};
Calibartion ACC_Cal_scales = {0,0,0};

void WriteFlashSixFloat(uint32_t write_addr, float W_Data1, float W_Data2, float W_Data3, float W_Data4, float W_Data5, float W_Data6)
{	
	//uint32_t secpos; //������ַ =ҳ��ַ
	//uint16_t secoff; //������ƫ�Ƶ�ַ(16bit����)
	//uint16_t secremain;//������ʣ��  ��ַ(16bit����)
	//uint16_t i;
	//uint32_t offaddr; //ȥ�� STM32_FLASH_BASE��ĵ�ַ
	
				
	 uint32_t Buffer[9]={0};				
	
   Buffer[0]=*(uint32_t*)(&W_Data1);   //���������ó�����������
	 Buffer[1]=*(uint32_t*)(&W_Data2);
	 Buffer[2]=*(uint32_t*)(&W_Data3);
	 Buffer[3]=*(uint32_t*)(&W_Data4);
	 Buffer[4]=*(uint32_t*)(&W_Data5);
	 Buffer[5]=*(uint32_t*)(&W_Data6);							

	
  //if(write_addr<STM32_FLASH_BASE || (write_addr>=(STM32_FLASH_BASE+1024*STM32_FLASH_SIZE)))
	//	return; //�Ƿ���ַ
	
	//offaddr = write_addr - STM32_FLASH_BASE; //ʵ��ƫ�Ƶ�ַ
	//secpos = offaddr / STM_SECTOR_SIZE;    //������ַ 0~  stm32f10rct6
	//secoff = (offaddr % STM_SECTOR_SIZE) / 2 ; // �������ڵ�ƫ�ƣ�2���ֽ�Ϊ������λ��
	
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	//FLASHStatus = FLASH_ErasePage(secpos*STM_SECTOR_SIZE+STM32_FLASH_BASE); // ��ַ TM�ľ���д����Ǹ���ַ���յ�
	FLASHStatus = FLASH_ErasePage(WRITE_START_ADDR);												
	if(FLASHStatus == FLASH_COMPLETE)
	{
		FLASHStatus = FLASH_ProgramWord(WRITE_START_ADDR+write_addr, Buffer[0]);
		FLASHStatus = FLASH_ProgramWord(WRITE_START_ADDR+write_addr +4, Buffer[1]);
		FLASHStatus = FLASH_ProgramWord(WRITE_START_ADDR+write_addr +8, Buffer[2]);
		FLASHStatus = FLASH_ProgramWord(WRITE_START_ADDR+write_addr +12, Buffer[3]);
		FLASHStatus = FLASH_ProgramWord(WRITE_START_ADDR+write_addr +16, Buffer[4]);
		FLASHStatus = FLASH_ProgramWord(WRITE_START_ADDR+write_addr +20, Buffer[5]);
		//FLASHStatus = FLASH_ProgramHalfWord(secpos*STM_SECTOR_SIZE+STM32_FLASH_BASE +24, Buf[6]);
		//stm32f10x_flash.c �� API ����
	}
	FLASH_Lock();
}


void Write_Flash_PID_Parameter(uint32_t write_addr, Flash_Save_PID pid1, Flash_Save_PID pid2, Flash_Save_PID pid3, Flash_Save_PID pid4, Flash_Save_PID pid5, 
	                                                  Flash_Save_PID pid6, Flash_Save_PID pid7, Flash_Save_PID pid8, Flash_Save_PID pid9, Flash_Save_PID pid10, Flash_Save_PID pid11)
{
	uint32_t Buffer[33]={0};
	int i =0;
  Buffer[0]=*(uint32_t*)(&pid1.p);   
  Buffer[1]=*(uint32_t*)(&pid1.i);
	Buffer[2]=*(uint32_t*)(&pid1.d);
	Buffer[3]=*(uint32_t*)(&pid2.p);
  Buffer[4]=*(uint32_t*)(&pid2.i);
	Buffer[5]=*(uint32_t*)(&pid2.d);	
  Buffer[6]=*(uint32_t*)(&pid3.p);   
  Buffer[7]=*(uint32_t*)(&pid3.i);
	Buffer[8]=*(uint32_t*)(&pid3.d);
	Buffer[9]=*(uint32_t*)(&pid4.p);
  Buffer[10]=*(uint32_t*)(&pid4.i);
	Buffer[11]=*(uint32_t*)(&pid4.d);		
	Buffer[12]=*(uint32_t*)(&pid5.p);   
  Buffer[13]=*(uint32_t*)(&pid5.i);
	Buffer[14]=*(uint32_t*)(&pid5.d);
	Buffer[15]=*(uint32_t*)(&pid6.p);
  Buffer[16]=*(uint32_t*)(&pid6.i);
	Buffer[17]=*(uint32_t*)(&pid6.d);	
  Buffer[18]=*(uint32_t*)(&pid7.p);   
  Buffer[19]=*(uint32_t*)(&pid7.i);
	Buffer[20]=*(uint32_t*)(&pid7.d);
	Buffer[21]=*(uint32_t*)(&pid8.p);
  Buffer[22]=*(uint32_t*)(&pid8.i);
	Buffer[23]=*(uint32_t*)(&pid8.d);	
	Buffer[24]=*(uint32_t*)(&pid9.p);
  Buffer[25]=*(uint32_t*)(&pid9.i);
	Buffer[26]=*(uint32_t*)(&pid9.d);		
	Buffer[27]=*(uint32_t*)(&pid10.p);   
  Buffer[28]=*(uint32_t*)(&pid10.i);
	Buffer[29]=*(uint32_t*)(&pid10.d);
	Buffer[30]=*(uint32_t*)(&pid11.p);
  Buffer[31]=*(uint32_t*)(&pid11.i);
	Buffer[32]=*(uint32_t*)(&pid11.d);	
	
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	FLASHStatus = FLASH_ErasePage(PID_Flash_STARTADDR);	
	if(FLASHStatus == FLASH_COMPLETE)
	{
			for(i=0;i<33;i++)
	    {
		     FLASHStatus = FLASH_ProgramWord(PID_Flash_STARTADDR+write_addr+4*i, Buffer[i]);
	    }
	
	}
	FLASH_Lock();
}


uint8_t ReadFlashThreeFloat(uint32_t read_addr, float *Data1,  float *Data2,  float *Data3)
{
	int i=0;
	uint8_t buf[12];
	uint8_t flag=0x00;
	//��ȡ���ݵı����ǽ����Ե�ַת��Ϊ��Ӧָ�룬Ȼ��ȡָ��ָ��λ�õ�����
	read_addr = (uint32_t)WRITE_START_ADDR + read_addr;
	*Data1 = *(float *)(read_addr);
	*Data2 = *(float *)(read_addr+4);
	*Data3 = *(float *)(read_addr+8);
	FLASH_Lock();
	//flash���� һ��ʼΪȫ0xff  ֻ�ܰ�1 дΪ0    д1= ȫ���� 
	for(i=0;i<12;i++)
	{
		*(buf+i) =  *(volatile uint8 *)read_addr++;
	}
	//buf+1 �ǵ�ַ����    *(buf+1)  ��ʾ�����ַ��ֵ
	if((buf[0]==0xff&&buf[1]==0xff&&buf[2]==0xff&&buf[3]==0xff))
       flag=flag|0x01;  // | ����
  if((buf[4]==0xff&&buf[5]==0xff&&buf[6]==0xff&&buf[7]==0xff))
       flag=flag|0x02;
  if((buf[8]==0xff&&buf[9]==0xff&&buf[10]==0xff&&buf[11]==0xff))
		  flag=flag|0x04;
		return flag;
}	



void Read_Flash_Data(void)
{
	Parameter_Read_Flag.accel_offset = ReadFlashThreeFloat(Acc_Offset_Address, &ACC_Cal_offset.X, &ACC_Cal_offset.Y, &ACC_Cal_offset.Z);
	Parameter_Read_Flag.accel_scale = ReadFlashThreeFloat(Acc_Scale_Address, &ACC_Cal_scales.X, &ACC_Cal_scales.Y, &ACC_Cal_scales.Z);
	
	if(Parameter_Read_Flag.accel_offset != 0x07 && Parameter_Read_Flag.accel_scale != 0x07) //flag | 0x01 |0x02|0x04  =0x07
	{
		/*b1b2b3 k1k2k3 === */
	B[0]= ACC_Cal_offset.X;
	B[1]= ACC_Cal_offset.Y;
	B[2]= ACC_Cal_offset.Z;
	K[0]= ACC_Cal_scales.X;
	K[1]= ACC_Cal_scales.Y;
	K[2]= ACC_Cal_scales.Z;
	}
	
	
	
}

void Write_Flash_Data(void)
{
	WriteFlashSixFloat(Acc_Offset_Address, new_offset.x, new_offset.y, new_offset.z, new_scales.x,  new_scales.y, new_scales.z);
	 //uint32_t Buffer[9]={0};
	 /*
   Buffer[0]=*(uint32_t*)(&new_offset.x);   //���������ó�����������
	 Buffer[1]=*(uint32_t*)(&new_offset.y);
	 Buffer[2]=*(uint32_t*)(&new_offset.z);
	 Buffer[3]=*(uint32_t*)(&new_scales.x);
	 Buffer[4]=*(uint32_t*)(&new_scales.y);
	 Buffer[5]=*(uint32_t*)(&new_scales.z);
	*/
	//MemWriteByte(Buffer, 6, 0x0803b000);
	
}


uint8_t MemWriteByte(uint32_t *data,uint16_t num, uint32_t write_addr)
{
	

	FLASH_Status temp_stat;

	uint32_t temp_addr = write_addr;

	FLASH_Unlock();
// Flash??,??????????

	temp_stat = FLASH_ErasePage(temp_addr);
// ??????

	if(temp_stat != FLASH_COMPLETE)
	{
     FLASH_Lock();
     return 0;
  }
  while(num --)
  {
     temp_stat = FLASH_ProgramWord(temp_addr,*data);
     if(temp_stat != FLASH_COMPLETE)
     {  
        FLASH_Lock();
        return 0;
     }
  temp_addr += 4;
  data++;
  }
  FLASH_Lock();
  return 1;
}

