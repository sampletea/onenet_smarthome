#ifndef _MPU6050_H
#define _MPU6050_H

#define Device_Address   0xD0
#define GRAVITY_MSS 9.7877f  //  nanning  9.7877f                   wuhan9.80665f 
#define ONE_G_TO_ACCEL 2048.0f/GRAVITY_MSS

#define GYRO_SCALE_2000  (0.0174532f / 16.4f)
#define GYRO_SCALE_1000  (0.0174532f / 32.8f)
#define GYRO_SCALE_500  (0.0174532f / 65.5f)
#define SCALE_250  (0.0174532f / 131f)
// Accelerometer scale adjustment
#define ACCEL_SCALE_16G   (GRAVITY_MSS / 2048.0f)
#define ACCEL_SCALE_8G    (GRAVITY_MSS / 4096.0f)
#define ACCEL_SCALE_4G    (GRAVITY_MSS / 8192.0f)
#define ACCEL_SCALE_2G    (GRAVITY_MSS / 16384.0f)


#define	SMPLRT_DIV		0x19
#define	MPU6050_CONFIG		0x1A
#define	GYRO_CONFIG		0x1B
#define	ACCEL_CONFIG	        0x1C
#define	ACCEL_XOUT_H	        0x3B
#define	ACCEL_XOUT_L	        0x3C
#define	ACCEL_YOUT_H	        0x3D
#define	ACCEL_YOUT_L	        0x3E
#define	ACCEL_ZOUT_H	        0x3F
#define	ACCEL_ZOUT_L	        0x40
#define	TEMP_OUT_H		0x41
#define	TEMP_OUT_L		0x42
#define	GYRO_XOUT_H		0x43
#define	GYRO_XOUT_L		0x44
#define	GYRO_YOUT_H		0x45
#define	GYRO_YOUT_L		0x46
#define	GYRO_ZOUT_H		0x47
#define	GYRO_ZOUT_L		0x48
#define	PWR_MGMT_1		0x6B
#define	WHO_AM_I		0x75
#define USER_CTRL		0x6A
#define INT_PIN_CFG		0x37



#define MPU6050_DLPF_BW_256         0x00    //��ͨ�˲�Ƶ�� 256hz
#define MPU6050_DLPF_BW_188         0x01    
#define MPU6050_DLPF_BW_98          0x02
#define MPU6050_DLPF_BW_42          0x03
#define MPU6050_DLPF_BW_20          0x04
#define MPU6050_DLPF_BW_10          0x05
#define MPU6050_DLPF_BW_5           0x06

void MPU6050_Initialize(void);
void Get_Gyro(void);
void Get_Acc(void);
void IMU_Gyro_Calibration(void);

void Get_MPU_Data(void);
void MPU_Data_Filter(void);
signed short Get_Data(unsigned char REG_Address);
float W_S_A_Filter(float New_Value, float *data);

extern unsigned char _cnt;

extern float acc_x, acc_y, acc_z, gyro_x, gyro_y, gyro_z;
extern float Acce_Correct[3];
//extern float gyro_o_v_X, gyro_o_v_Y, gyro_o_v_Z; 
extern float gyro_v_a_o_c_X, gyro_v_a_o_c_Y, gyro_v_a_o_c_Z;
extern float acc_v_a_o_c_X, acc_v_a_o_c_Y, acc_v_a_o_c_Z ; 
extern float Filter_Corret_Gyro_X, Filter_Corret_Gyro_Y, Filter_Corret_Gyro_Z;
extern float Filter_Corret_Gyro_X1, Filter_Corret_Gyro_Y1, Filter_Corret_Gyro_Z1;
extern float Filter_Corret_Acc_X, Filter_Corret_Acc_Y, Filter_Corret_Acc_Z;
extern float Filter_Corret_Acc_X1, Filter_Corret_Acc_Y1, Filter_Corret_Acc_Z1;

extern float B[3],K[3];

#endif

