#ifndef _PPM_H
#define _PPM_H

#define  Yaw_Max     100

#define Lock_Controler  0
#define Unlock_Controler  1


extern uint16 PPM_Databuf[10];
extern u32 TIME_ISR_CNT;
extern u16 Controler_State;
extern uint16 PPM_Isr_Cnt;

extern uint16 Throttle_Control;
extern int16 Target_Angle[2];
extern int16 Pitch_Control,Roll_Control,Yaw_Control;

void PPM_Init(void);
void PPM_RC(void);


#endif

