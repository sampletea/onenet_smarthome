#ifndef _FILTER_H
#define _FILTER_H


typedef struct {
	
	float Input_Butter[3];
	float Output_Butter[3];
}Butterworth_BufferData;

typedef struct {
	
	float a[3];
	float b[3];
}Butterworth_Parameter;


extern Butterworth_BufferData Butter_5HZ_Buffer_Acce[3];

extern Butterworth_Parameter Butterworth_30HZ_Parameter_Acce, Gyro_Parameter,Butterworth_1HZ_Parameter_Acce;

float LPButterworth(float curr_input,Butterworth_BufferData *Buffer,Butterworth_Parameter *Parameter);
float MPU_LPF(float curr_inputer,
               Butterworth_BufferData *Buffer,
               Butterworth_Parameter *Parameter);
#endif

