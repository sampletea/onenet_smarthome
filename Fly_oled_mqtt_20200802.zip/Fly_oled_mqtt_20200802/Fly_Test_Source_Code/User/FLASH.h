#ifndef _FLASH_H
#define _FLASH_H
//                            0x0803b800 ->ת10����=243712 /1024 =238  ---   256k-238k=18k  
//                            0x0803A000    ---0x3A000  ת10����=247568 /1024 =232  ---   256k-232k=24k  
#define PID_Flash_STARTADDR  0x0803A800  //0x3A800 ->ת10����=239616 /1024 =234  ---   256k-234k=22k  
#define PID1_Address  0
#define PID2_Address  12
#define PID3_Address  24
#define PID4_Address  36
#define PID5_Address  48
#define PID6_Address  60
#define PID7_Address  72
#define PID8_Address  84
#define PID9_Address  96
#define PID10_Address 108
#define PID11_Address 120


typedef struct
{
	float X;
	float Y;
	float Z;
}Calibartion;

typedef struct
{
	uint8_t accel_offset;
	uint8_t accel_scale;
	uint8_t mag;
}Parameter_Flag;


void wtite_half_word(uint32_t write_addr, uint32_t write_data);
void WriteFlashSixFloat(uint32_t write_addr, float W_Data1, float W_Data2, float W_Data3, float W_Data4, float W_Data5, float W_Data6);
uint8_t ReadFlashThreeFloat(uint32_t read_addr, float *Data1,  float *Data2,  float *Data3);
void Read_Flash_Data(void);
void Write_Flash_Data(void);
uint8_t MemWriteByte(uint32_t *data,uint16_t num, uint32_t write_addr);
void Write_Flash_PID_Parameter(uint32_t write_addr, Flash_Save_PID pid1, Flash_Save_PID pid2, Flash_Save_PID pid3, Flash_Save_PID pid4, Flash_Save_PID pid5, 
	                                                  Flash_Save_PID pid6, Flash_Save_PID pid7, Flash_Save_PID pid8, Flash_Save_PID pid9, Flash_Save_PID pid10, Flash_Save_PID pid11);
#endif
