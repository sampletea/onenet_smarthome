#include "Headfile.h"
#include "IIC.h"
#include "stdio.h"




void IIC_Init(void)
{			
	GPIO_InitTypeDef GPIO_InitStructure;
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);			     
 	//PB6 PB7 ��©���  ˢ��Ƶ��10Mhz
 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;	
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;       
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	Delay_Ms(15);
  GPIO_SetBits(GPIOB, GPIO_Pin_6 | GPIO_Pin_7);
	//printf("IIC bus init success...\r\n");
  Flag.IIC_Init_OK = 1;
	
}

//SCL-->PB6
//SDA-->PB7

//SDA���ģʽ
void SDA_OUT(void)
{
	
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_7 ;
	
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

//SDA����ģʽ
void SDA_IN(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_7 ;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; // ��������
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}


static void IIC_delay(void)
{
    volatile int i = 7;	//7
    while (i)
        i--;
}

void IIC_Start(void) {
	
	SDA_OUT();
	SCL_H;
	SDA_H;
	IIC_delay();
	SDA_L;
	IIC_delay();
}
//**************************
void IIC_Stop(void)
{
	SDA_OUT();
	SCL_L;
	IIC_delay();
	SDA_L;
	IIC_delay();
	SCL_H;
	IIC_delay();
	SDA_H;
	IIC_delay();
}
//**************
unsigned char IIC_SlaveAck(void)
{
	SDA_OUT();
	SCL_L;
	IIC_delay();
	SDA_H;

	SDA_IN();
	IIC_delay();
	SCL_H;

	IIC_delay();

	if(SDA_read)
	{
		SCL_L;
		return 0;
	}
	SCL_L;
	IIC_delay();
	return 1;
}

/**************************
����һ��Byte(�ֽ�)  ---һ���ֽ�8λ    �����ֽ�=����(16λ) 
                             �ĸ��ֽ� = �� ��32λ ��
SenByte
���ݴӸ�λ����λ
****************************/
void IIC_SendByte(unsigned char SendByte){
	unsigned char i = 8;
	
	SDA_OUT();
	while(i--){
		SCL_L;
		IIC_delay();
		if(SendByte & 0x80)
			SDA_H;
		else
			SDA_L;
		SendByte <<= 1;  // SendByte = SendByte << 1;
		IIC_delay();
		SCL_H;
		IIC_delay();
	}
	
	SCL_L;
	if(IIC_SlaveAck() == 0){
		return;
	}
}
/**************************
��ȡһ���ֽ�    ---һ���ֽ�8λ    �����ֽ�=����(16λ) 
                             �ĸ��ֽ� = �� ��32λ ��
ReceiveByte
���ݴӸ�λ����λ
****************************/

unsigned char IIC_ReceviByte(void) {
	unsigned char i = 8;
	unsigned char ReceviByte = 0;
	SDA_IN();
	SDA_H;
	while(i--){
		ReceviByte <<= 1;
		SCL_L;
		IIC_delay();
		SCL_H;
		IIC_delay();
		if(SDA_read){
			ReceviByte |= 0x01;
		}
	}
	
	SCL_L;
	return ReceviByte;
}

/*****************************
 WriteAddress,--д���ַ  DeviceAddress -- ������ַ    ���ֽ�д�� 
******************************/
void Single_IIC_WriteByte(unsigned char WriteAddress, unsigned char DeviceAddress, unsigned char SendByte) {
	IIC_Start();
  IIC_SendByte(WriteAddress);
  IIC_SendByte(DeviceAddress);
  IIC_SendByte(SendByte);
  IIC_Stop();
	//return true;
}

unsigned char Single_ReadIIC(unsigned char SlaveAddress,unsigned char REG_Address)
{
	unsigned char REG_data;
	IIC_Start();
	IIC_SendByte(SlaveAddress);
	IIC_SendByte(REG_Address);
	IIC_Start();
	IIC_SendByte(SlaveAddress+1);
	REG_data = IIC_ReceviByte();
	IIC_SlaveAck();
	IIC_Stop();
	return REG_data;
}

unsigned short int Double_ReadIIC(unsigned char SlaveAddress,unsigned char REG_Address)
{
	unsigned char msb , lsb ;
	msb = Single_ReadIIC(SlaveAddress,REG_Address);
	lsb = Single_ReadIIC(SlaveAddress,REG_Address+1);
	return ( ((unsigned short int)msb) << 8 | lsb) ;
}

unsigned long int Three_ReadIIC(unsigned char SlaveAddress,unsigned char REG_Address)
{
	unsigned char msb , lsb,xlsb;
	msb = Single_ReadIIC(SlaveAddress,REG_Address);
	lsb = Single_ReadIIC(SlaveAddress,REG_Address+1);
        xlsb= Single_ReadIIC(SlaveAddress,REG_Address+2);
	return (((unsigned long int)msb<< 16)|((unsigned long int)lsb<<8)|xlsb) ;
}

