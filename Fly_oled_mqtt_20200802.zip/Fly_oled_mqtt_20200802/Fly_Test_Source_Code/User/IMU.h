#ifndef _IMU_H
#define _IMU_H


#define PI                 3.14159265358979f
#define DEG2RAD (PI / 180.0f)   //DEG to RAD �Ƕ�ת����
#define RAD2DEG (180.0f / PI)    //RAD to DEG ����ת�Ƕ�

extern float Pitch, Roll, Yaw;
extern float Yaw_Gyro, Pitch_Gyro, Roll_Gyro;

extern float Z_Axis_Angular_Velocity_Of_Navigation_System;
extern float Gyro_Length;

void IMUupdate(float gx, float gy, float gz, float ax, float ay, float az);

float invSqrt(float x);  
void Acc_Calculate_Angle(float ax, float ay, float az);


#endif



