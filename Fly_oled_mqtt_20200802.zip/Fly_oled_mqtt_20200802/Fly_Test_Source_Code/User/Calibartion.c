#include "Headfile.h"
#include "Calibartion.h"


uint8_t flight_direction=6;
uint8_t Accel_Calibration_Finished[6]={0,0,0,0,0,0};//
uint8_t Accel_Calibration_All_Finished=0;//6????????????
uint8_t Cal_Flag=0;
Acc_Cal Acc_Each_Side_Data[6]={0};
Acc_Cal new_offset={
  0,0,0,
};
Acc_Cal new_scales={
  1.0,1.0,1.0,
};


unsigned char Accel_Calibartion(void)
{
	int i;
	Acc_get_six_sides_of_data();
	
  if((Accel_Calibration_Finished[0]
		  &Accel_Calibration_Finished[1]
	    &Accel_Calibration_Finished[2]
	    &Accel_Calibration_Finished[3]
	    &Accel_Calibration_Finished[4]
	    &Accel_Calibration_Finished[5])
	    &&Accel_Calibration_All_Finished==0)
	{
		Accel_Calibration_All_Finished=1;//6�����ݼ�¼���
		Flag.Accel_Calibration_Flag=0;//���ٶȼ�У׼ģʽ����,�ͷ�ҡ��
		
		Cal_Flag=Calibrate_accel(Acc_Each_Side_Data,
                                &new_offset,
                                  &new_scales);//�����õ���6�����ݴ���ú���
	  for(i=0;i<6;i++)
    {
      Accel_Calibration_Finished[i]=0;//��Ӧ  ���־λ����
		
    }
	  if(Cal_Flag==true)
	  {
		   ///д�����
			
			Write_Flash_Data();
			Read_Flash_Data();  //��ȡ��У׼�Ĳ���
			LED_MODE=0;  //LED��˸ģʽ�ص�����ģʽ
			LED_Set(&LED_5,3000,200,0.8,0,GPIOC,GPIO_Pin_4,0);
			LED_Set(&LED_3,3000,200,0.3,0,GPIOC,GPIO_Pin_5,0);
			LED_Set(&LED_4,3000,200,0.5,0,GPIOC,GPIO_Pin_10,0);
			 return true;
	  }
		else   //У׼ʧ��
		{
			//
		}
	
  }
	return false;
}




void Calibrate_Reset_Matrices(float dS[6], float JS[6][6])
{
    int16_t j,k;
    for( j=0; j<6; j++ )
    {
        dS[j] = 0.0f;
        for( k=0; k<6; k++ )
        {
            JS[j][k] = 0.0f;
        }
    }
}

void Calibrate_Find_Delta(float dS[6], float JS[6][6], float delta[6])
{
    //Solve 6-d matrix equation JS*x = dS
    //first put in upper triangular form
    int16_t i,j,k;
    float mu;
    //make upper triangular
    for( i=0; i<6; i++ ) {
        //eliminate all nonzero entries below JS[i][i]
        for( j=i+1; j<6; j++ ) {
            mu = JS[i][j]/JS[i][i];
            if( mu != 0.0f ) {
                dS[j] -= mu*dS[i];
                for( k=j; k<6; k++ ) {
                    JS[k][j] -= mu*JS[k][i];
                }
            }
        }
    }
    //back-substitute
    for( i=5; i>=0; i-- ) {
        dS[i] /= JS[i][i];
        JS[i][i] = 1.0f;

        for( j=0; j<i; j++ ) {
            mu = JS[i][j];
            dS[j] -= mu*dS[i];
            JS[i][j] = 0.0f;
        }
    }
    for( i=0; i<6; i++ ) {
        delta[i] = dS[i];
    }
}

void Calibrate_Update_Matrices(float dS[6],
                               float JS[6][6],
                               float beta[6],
                               float data[3])
{
    int16_t j, k;
    float dx, b;
    float residual = 1.0;
    float jacobian[6];
    for(j=0;j<3;j++)
    {
        b = beta[3+j];
        dx = (float)data[j] - beta[j];
        residual -= b*b*dx*dx;
        jacobian[j] = 2.0f*b*b*dx;
        jacobian[3+j] = -2.0f*b*dx*dx;
    }

    for(j=0;j<6;j++)
    {
        dS[j]+=jacobian[j]*residual;
        for(k=0;k<6;k++)
        {
            JS[j][k]+=jacobian[j]*jacobian[k];
        }
    }
}




void Acc_get_six_sides_of_data(void)
{
	int num_samples = 0;
	int j;
	float Acc_get_six_sides_of_data_sum[3] = {0};
	
	if(flight_direction <= 5)
	{
		while(num_samples < 1000 && Flag.Acce_Correct_Update_Flag ==1)
	  {
			
		  if(Gyro_Length < 20.0f )
		  {
				for(j=0;j<3;j++)
			  {
				   Acc_get_six_sides_of_data_sum[j] += Acce_Correct[j] *  ACCEL_SCALE_16G; 
			  }
			  num_samples++;
		    Flag.Acce_Correct_Update_Flag =0;
		  }
		
		Accel_Calibration_Finished[flight_direction]=1;//��ӭ��У׼���
	  }
		
	
	  Acc_Each_Side_Data[flight_direction].x = Acc_get_six_sides_of_data_sum[0] / num_samples;
	  Acc_Each_Side_Data[flight_direction].y = Acc_get_six_sides_of_data_sum[1] / num_samples;
	  Acc_Each_Side_Data[flight_direction].z = Acc_get_six_sides_of_data_sum[2] / num_samples;
	  flight_direction =6;
	}
}


uint16_t Accel_Calibration_Makesure_Cnt=0;
uint16_t Accel_flight_direction_cnt=0;
void Accel_Calibration_Check(void)
{
	
	uint16_t  i=0;
	if(Throttle_Control==1000 && Yaw_Control>= 80 && Roll_Control<=-30 && Pitch_Control>=30)
  {
      Accel_Calibration_Makesure_Cnt++;
  }
	
	if(Throttle_Control==1000&&Yaw_Control>=80
		&&Roll_Control<=-30
		&&Pitch_Control>=30
		&&Accel_Calibration_Makesure_Cnt>=200*1   //2s
	   &&Controler_State==Lock_Controler)  //����״̬�
	{
		Flag.Accel_Calibration_Flag=1;  //���ټ�У׼ģʽ
		
	  LED_MODE=1; //led������ټ�У׼��˸ģʽ�
		LED_Set(&LED_3,1000,100,0.5,0,GPIOC,GPIO_Pin_10,1);
		LED_Set(&LED_4,1000,100,0.5,0,GPIOC,GPIO_Pin_5,1);
		LED_Set(&LED_5,1000,100,0.5,0,GPIOC,GPIO_Pin_4,1);
		Cal_Flag=0;
		flight_direction=6;
		Accel_Calibration_All_Finished=0;
		Accel_Calibration_Makesure_Cnt=0;
		for(i=0;i<6;i++)
		{
			Accel_Calibration_Finished[i]=0;
			Acc_Each_Side_Data[i].x=0; //��Ӧ������
			Acc_Each_Side_Data[i].y=0; //��Ӧ������
			Acc_Each_Side_Data[i].z=0; //��Ӧ������
		}
			
	}
	/*��һ��ɿ�ƽ�ţ�Z�����������Ϸ���Z axis is about 1g,X��Y is about 0g*/
        /*�ڶ���ɿ�ƽ�ţ�X�����������Ϸ���X axis is about 1g,Y��Z is about 0g*/
         /*������ɿ�ƽ�ţ�X�����������·���X axis is about -1g,Y��Z is about 0g*/
        /*������ɿ�ƽ�ţ�Y�����������·���Y axis is about -1g,X��Z is about 0g*/
        /*������ɿ�ƽ�ţ�Y�����������Ϸ���Y axis is about 1g,X��Z is about 0g*/
       /*������ɿ�ƽ�ţ�Z�����������·���Z axis is about -1g,X��Y is about 0g*/
  if(Flag.Accel_Calibration_Flag==1)
	{
		if(Throttle_Control==1000&&Yaw_Control<=-Yaw_Max*0.7f&&Roll_Control==0&&Pitch_Control==0)
		{
			Accel_flight_direction_cnt++;
			if(Accel_flight_direction_cnt>=5*10) //100ms
			{
				flight_direction=0;
			}
		}
		else if(Throttle_Control==1000&&Yaw_Control==0&&Roll_Control>=30&&Pitch_Control==0)
		{
			Accel_flight_direction_cnt++;
			if(Accel_flight_direction_cnt>=5*10) //100ms
			{
				flight_direction=1;
			}
		}
		else if(Throttle_Control==1000&&Yaw_Control==0&&Roll_Control<=-30&&Pitch_Control==0)
		{
			Accel_flight_direction_cnt++;
			if(Accel_flight_direction_cnt>=5*10) //100ms
			{
				flight_direction=2;
			}			
		}
		else if(Throttle_Control==1000&&Yaw_Control==0&&Roll_Control==0&&Pitch_Control>=30)
		{
			Accel_flight_direction_cnt++;
			if(Accel_flight_direction_cnt>=5*10) //100ms
			{
				flight_direction=3;
		  }
		}
		else if(Throttle_Control==1000&&Yaw_Control==0&&Roll_Control==0&&Pitch_Control<=-30)
		{
			Accel_flight_direction_cnt++;
			if(Accel_flight_direction_cnt>=5*10) //100ms
			{
				flight_direction=4;
		  }
		}
		else if(Throttle_Control==1000&&Yaw_Control>Yaw_Max*0.7f&&Roll_Control==0&&Pitch_Control==0)
		{
			Accel_flight_direction_cnt++;
			if(Accel_flight_direction_cnt>=5*10) //100ms
			{
				flight_direction=5;
		  }
		}
		else
		{
			Accel_flight_direction_cnt/=2;
		}
		
		if(Accel_flight_direction_cnt>=200)  Accel_flight_direction_cnt=0;
		
  }
	

}


/***************************************/
uint16_t Check_Calibartion_Flag(void)
{
	uint16_t cal_flag=0x00; 
	if(Flag.Accel_Calibration_Flag == 1) cal_flag = 0x01;
	return cal_flag;
}



	
/************************************************************************************/
unsigned char Calibrate_accel(Acc_Cal Acc_Each_Side_Data[6],
                      Acc_Cal *accel_offsets,
                      Acc_Cal *accel_scale)
{
	  int16_t i;
    int16_t num_iterations = 0;
    float eps = 0.000000001;
    float change = 100.0;
    float data[3]={0};
    float beta[6]={0};
    float delta[6]={0};
    float ds[6]={0};
    float JS[6][6]={0};
    bool success = true;
    // reset
    beta[0] = beta[1] = beta[2] = 0;
    beta[3] = beta[4] = beta[5] = 1.0f/GRAVITY_MSS;
    while( num_iterations < 20 && change > eps ) {
        num_iterations++;
        Calibrate_Reset_Matrices(ds, JS);

        for( i=0; i<6; i++ ) {
            data[0] = Acc_Each_Side_Data[i].x;
            data[1] = Acc_Each_Side_Data[i].y;
            data[2] = Acc_Each_Side_Data[i].z;
            Calibrate_Update_Matrices(ds, JS, beta, data);

        }
        Calibrate_Find_Delta(ds, JS, delta);
        change =    delta[0]*delta[0] +
                    delta[0]*delta[0] +
                    delta[1]*delta[1] +
                    delta[2]*delta[2] +
                    delta[3]*delta[3] / (beta[3]*beta[3]) +
                    delta[4]*delta[4] / (beta[4]*beta[4]) +
                    delta[5]*delta[5] / (beta[5]*beta[5]);
        for( i=0; i<6; i++ ) {
            beta[i] -= delta[i];
        }
    }
    // copy results out
    accel_scale->x = beta[3] * GRAVITY_MSS;
    accel_scale->y = beta[4] * GRAVITY_MSS;
    accel_scale->z = beta[5] * GRAVITY_MSS;
    accel_offsets->x = beta[0] * accel_scale->x;
    accel_offsets->y = beta[1] * accel_scale->y;
    accel_offsets->z = beta[2] * accel_scale->z;

    // sanity check scale
    if(fabsf(accel_scale->x-1.0f) > 0.5f
         || fabsf(accel_scale->y-1.0f) > 0.5f
           || fabsf(accel_scale->z-1.0f) > 0.5f )
    {
        success = false;
    }
    // sanity check offsets (3.5 is roughly 3/10th of a G, 5.0 is roughly half a G)
    if(fabsf(accel_offsets->x) > 5.0f
         || fabsf(accel_offsets->y) > 5.0f
           || fabsf(accel_offsets->z) > 5.0f )
    {
        success = false;
    }
    // return success or failure
    return success;
}


