#include "Headfile.h"

/*************************************************************************************************************************
//----------------------------------------------------------------------------------------------------------------------//

	*		MCU: 	STM32F103RCT6  72MHz

	*		IMU(MPU6050 + IST8310 + SPL06_001):
	*				IMU_SCL						-->	PB6
	*				IMU_SDA						-->	PB7
	*		OLED:
	*				OLED_D0						-->	PC3
	*				OLED_D1						-->	PC2
	*				OLED_RST					-->	PC1
	*				OLED_DC						-->	PC0
	*				OLED_CS						-->	GND
	*		????:                  TIM3���ĸ�ͨ��CH1,CH2,CH3,CH4�ֱ��ӦPA6,PA7,PB0,PB1    ����ԭ��ͼ ��  �� ���ĸ�ͨ�������� ������
	*				MOTOR1						-->	PB1	-->	TIM3_CH4
	*				MOTOR2						-->	PB0	-->	TIM3_CH3
	*				MOTOR3						-->	PA7	-->	TIM3_CH2
	*				MOTOR4						-->	PA6	-->	TIM3_CH1
	*		RC??:
	*				PPM??					        -->	PA8	-->	TIM1_CH1
	*				SBUS??					-->	PB11-->	USART3_RX
	*		???:
	*				TRIG						-->	PB9  TRIG
	*				ECHO						-->	PA1  IO4
	*		??:
	*				S1						-->	PC8
	*				S2						-->	PC9
	*		LED:
	*				LED2(Green)			                -->	PA5
	*				LED3(Blue)				        -->	PC10
	*				LED4(Yellow) ?? ʵ�ʳ���ɫ��			                -->	PC5
	*				LED5(Red)			                -->	PC4
	*		SPI(Extended,3.3V)    ??????  &  ?????  MPU6500+HMC5983+MS5611
	*				SPI2_IRQ				        -->	PB12
	*				SPI2_SCK				        -->	PB13
	*				SPI2_MISO				        -->	PB14
	*				SPI2_MOSI				        -->	PB15
	*				SPI2_CE				          -->	PC6
	*				SPI2_CSN				        -->	PC7
	*		USART1(Wireless,3.3V)   ?????????  &  Mavlink    ESP8266
	*				USART1_TX				        -->	PA9
	*				USART1_RX				        -->	PA10
	*		USART2(Extended,5V)    ??GPS
	*				USART2_TX				        -->	PA2
	*				USART2_RX				        -->	PA3
	*		USART3(Extended,3.3V)  ????  ANO???????SBUS????
	*				USART3_TX				        -->	PB10
	*				USART3_RX				        -->	PB11
	*		??IO?
	*				IO1				              -->	PC13---esp8266��λ����
	*				IO2				              -->	PC14
	*				IO3				              -->	PC15
	*				IO4				              -->	PA1
************************************************************************************************************************/
char Pub_Buf[256];  //�ϴ�����buf
const char *devSubTopics[] = {"/mysmarthome/sub"};
const char devPubTopics[] = "/mysmarthome/Pub";
unsigned short timeCount = 0;	//���ͼ������
unsigned char *dataPtr = NULL;

int main(void) {

	SystemInit();
	cycleCounterInit();   //����ϵͳ��������ʱ��us
	SysTick_Config(SystemCoreClock / 1000);  //  Tick��ʱ��  1 ms�ж�
	USART1_Init(115200);  //8266ͨѶ���� mv
	USART2_Init(115200);  //��ӡ���Կ�
	OLED_Init();//��ʾ����ʼ��
	Bling_Init(); //ָʾ�ơ�����IO��ʼ��
	Delay_Ms(200);
	PPM_Init();
	HC_SR04_Init();
	Moto_PWM_Init();
	IIC_Init();
	
  MPU6050_Initialize();
	
	
	#ifdef IMU_BOARD_NC686
	
	  //IST8310_Init();
	  Delay_Ms(100);
	  spl0601_init();
	  
	#endif
	Quad_Start_LED();
	Delay_Ms(100);
	IMU_Gyro_Calibration();   //  ����gyro ƫ��ֵ
	USART3_Init(115200); //debug ��
	Read_Flash_Data();  //��ȡFlash�е�K[0] K[1] K[2]  B[0] B[1] B[2]
	PID_Init();
	Read_Flash_PID_Parameter();  //��ȡFlash�е�PID����
	

	
	Time2_Configuration();
	TIM4_Configuration_Cnt();
	
	//����ϵͳ�ж����ȼ�
	NVIC_Configuration();
	
//		ESP8266_Init();  //esp8266��ʼ��
////	while(OneNet_DevLink())			//����OneNET
//    OneNet_DevLink();
//		Delay_Ms(500);
//	OneNet_Subscribe(devSubTopics, 1);
	
	
	
	while(1) {
		OLED_Show();
		
		if(++timeCount >= 45)									//���ͼ��5s      45��Լ  6��
		{
//			UsartPrintf(USART_DEBUG, "OneNet_Publish\r\n");
//			sprintf(Pub_Buf,  "{\"gx\":%1f}, \"gy\":%1f}, \"gz\":%1f}", gyro_x,gyro_y,gyro_z);
////		OneNet_Publish(devPubTopics, "MQTT Publish Test 11112222222221121121");  //�ϴ��Ķ���
//			OneNet_Publish(devPubTopics,Pub_Buf);  //�ϴ��Ķ���
//			timeCount = 0;
//			ESP8266_Clear();
			  
			
			UsartPrintf(USART_DEBUG, "%0.1f mm\r\n",HC_SR04_Distance);
			timeCount = 0;
		}
//		
//		dataPtr = ESP8266_GetIPD(3);
//		if(dataPtr != NULL)
//			OneNet_RevPro(dataPtr);
//		Delay_Ms(10);
		
		Accel_Calibartion();  
		Save_PID_Parameter_Flash();
	}
		
}
