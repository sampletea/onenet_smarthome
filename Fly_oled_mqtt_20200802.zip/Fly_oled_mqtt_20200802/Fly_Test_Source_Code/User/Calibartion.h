#ifndef _Calibartion_H
#define _Calibartion_H

typedef struct 
{
	float x;
	float y;
	float z;
}Acc_Cal;
extern Acc_Cal new_offset;
extern Acc_Cal new_scales;

extern uint8_t flight_direction;

unsigned char Calibrate_accel(Acc_Cal Acc_Each_Side_Data[6],
                      Acc_Cal *accel_offsets,
                      Acc_Cal *accel_scale);
void Calibrate_Reset_Matrices(float dS[6], float JS[6][6]);
void Calibrate_Find_Delta(float dS[6], float JS[6][6], float delta[6]);
void Calibrate_Update_Matrices(float dS[6],
                               float JS[6][6],
                               float beta[6],
                               float data[3]);

void Accel_Calibration_Check(void);
unsigned char Accel_Calibartion(void);
void Acc_get_six_sides_of_data(void);
uint16_t Check_Calibartion_Flag(void);

#endif
