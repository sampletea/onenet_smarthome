#ifndef _TIME_H
#define _TIME_H
#include "stdint.h"

extern uint8_t LED_MODE;
extern uint16_t Microsecond,Second,Minute,Hour;
void Test_Period(Testime*t);
void Time2_Configuration(void);
void TIM2_IRQHandler(void);
void TIM4_Configuration_Cnt(void);
void TIM4_IRQHandler(void);
void PPM_RC(void);



#endif

