#ifndef _CONTROL_H
#define _CONTROL_H


#define ADRC_MODE  0
#define PID_MODE   1

#define GYRO_CONTROL_MODE  PID_MODE

void Total_Control(void);
void Fly_Mode_Select(void);
void Main_Leading_Control(void);
void Altitude_Control(void);
void Angle_Control(void);
void Gyro_Control(void);
void Total_Control_Output(void);
unsigned short Value_Limit(unsigned short data, unsigned short min, unsigned short max);
bool GPS_IS_OK(void);



typedef struct
{
	unsigned char Stability_Model ;   //����
  unsigned char High_Hold_Model ;   //����
	unsigned char Last_High_Hold_Model ; //�ϴ�
	unsigned char Horizontal_Model; //ˮƽλ�ö�λ
	unsigned char Last_Horizontal_Model; //�ϴ�
	unsigned char Positioning_Hover_Model; //ˮƽ+����
	unsigned char Last_Positioning_Hover_Model;//�ϴ�
	unsigned char Takeoff_Model; 
	unsigned char Return_To_Home_Model;
	unsigned char Last_Return_To_Home_Model; //�ϴ�
	unsigned char Mission_Flight;
	unsigned char Cruise_Flight;  //Ѳ������
}Mode;

typedef struct 
{
	unsigned char High_Hold_Flag;
	unsigned char Positioning_Hover_Flag;
	unsigned char Number_of_GPS;
	unsigned char GPS_Record_Home_Location;
	float GPS_Quality;  //GPSˮƽ�������� >6������
}set;
#endif
