#include "Headfile.h"
#include "Time.h"


u32 TIME_ISR_CNT=0, LAST_TIME_ISR_CNT=0;
uint16_t Microsecond_Cnt=0;
uint16_t Microsecond=0,Second=0,Minute=0,Hour=0;
uint8_t LED_MODE =0;
uint8 HC_SR04_Cnt=0;
/* TIM2_5ms��ʱ*/
void Time2_Configuration(void){
	
	  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    TIM_DeInit(TIM2);
    //TIM_TimeBaseStructure.TIM_Period = 60000;//30ms
    //TIM_TimeBaseStructure.TIM_Period = 20000;//10ms
	  //�����жϵ�ʱ��T = (arr+1)* (psc+1) / 72M          f= 1/T
	  // T = (TIM_Period + 1) * (TIM_Prescaler + 1) / TIM2 Clock  
    TIM_TimeBaseStructure.TIM_Period = 5000-1;//   5000*72/72000000= T  0.005s = 5ms
	
    TIM_TimeBaseStructure.TIM_Prescaler = 72-1; //
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

    TIM_ClearFlag(TIM2, TIM_FLAG_Update);
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
    TIM_Cmd(TIM2, ENABLE);
}


/*TIM4_10ms��ʱ */
void TIM4_Configuration_Cnt(void)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
    TIM_DeInit(TIM4);
     
    //  TIMx_Clock�Զ���Ƶ = 72M ��Ƶ��                              T = T_psc * arr    = 1/1000000 * 20000  =0.02s   = 20ms
    TIM_TimeBaseStructure.TIM_Period = 20000;// 20ms
    //TIM_TimeBaseStructure.TIM_Prescaler = 72-1;   //Ԥ��Ƶֵ72  f_psc = 72M/72= 1000000Hz   T_psc = 1/1000000s = 1/1000000  * 1000000 us = 1us
    TIM_TimeBaseStructure.TIM_Prescaler = 36-1; 
	  // Ԥ��Ƶֵ36   APB1 - 36Mʱ��Ƶ��  f_TIMx_Clock =2*APB1   f_psc  = 72M/36=2000000Hz  1/2000000s = 0.0000005 *1000000 us = 0.5us       1s = 1000000us 
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

    TIM_ClearFlag(TIM4, TIM_FLAG_Update);
    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
    TIM_Cmd(TIM4, ENABLE);
}

Testime Time2_Delta;
void TIM2_IRQHandler(void)//5msˢ��һ��
{
	
  if( TIM_GetITStatus(TIM2,TIM_IT_Update)!=RESET )
	{
		Test_Period(&Time2_Delta);//ϵͳ����ʱ�������
		PPM_RC();
		Get_MPU_Data();
		Test_Period(&Time2_Delta);//ϵͳ����ʱ�������
    HC_SR04_Cnt++;
    if(HC_SR04_Cnt>=15)//75ms
    {
      HC_SR04_Start();
      HC_SR04_Cnt=0;
    }
		
		IMUupdate(Filter_Corret_Gyro_X, Filter_Corret_Gyro_Y, Filter_Corret_Gyro_Z,
		          Filter_Corret_Acc_X, Filter_Corret_Acc_Y, Filter_Corret_Acc_Z);
		Acc_Calculate_Angle(Filter_Corret_Acc_X, Filter_Corret_Acc_Y, Filter_Corret_Acc_Z);//���ٶȼ���ŷ����  ����Ϊ��̬����Ĺ۲�Ƕ�
		
		SINS_Prepare();
		
		Total_Control();
		Total_Control_Output();
		
		if(PPM_Isr_Cnt==100)
		{
			Accel_Calibration_Check();
		}
		
		
		
		
		LED_Work(LED_MODE);
//		
	  //SEND_STATAMACHINE_CONTROL();
		
		
		
		TIM_ClearITPendingBit(TIM2,TIM_FLAG_Update);
	}
}



void TIM4_IRQHandler(void)//10msˢ��һ��
{
	
  if( TIM_GetITStatus(TIM4,TIM_IT_Update)!=RESET )
	{
		LAST_TIME_ISR_CNT=TIME_ISR_CNT;
		TIME_ISR_CNT++;
		Microsecond_Cnt++;
		if(Microsecond_Cnt>=100)
		{
			//UsartPrintf(USART_DEBUG,"%0.f",Second);
			//UsartPrintf(USART_DEBUG,"%0.4f ms","%0.4f ms\r\n",Time2_Delta.Now_Time,Time2_Delta.Now_Time);
//			UsartPrintf(USART_DEBUG,"%0.4f ms\r\n",Time2_Delta.Time_Delta);
			Microsecond_Cnt=0;
			Second++;
		}
		if(Second>=60)
		{
			
			Second=0;
			
			Minute++;
			//UsartPrintf(USART_DEBUG,"%0.2",Minute);
		}
		if(Minute>=60)
		{
			Minute=0;
			Hour++;
		}
		Microsecond = Microsecond_Cnt;
		
		TIM_ClearITPendingBit(TIM4,TIM_FLAG_Update);
	}
}

void Test_Period(Testime*t)
{
	t->Last_Time = t->Now_Time;
	
	t->Now_Time = (1000*10*TIME_ISR_CNT + TIM4->CNT/2) / 1000.0; //ms
	
	t->Time_Delta = t->Now_Time - t->Last_Time;
	
	t->Time_Delta_INT = (unsigned short)(t->Time_Delta);
	
}

